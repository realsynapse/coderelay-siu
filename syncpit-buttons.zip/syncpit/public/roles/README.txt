Put the small picture for the "bauna" role here as bauna.png (transparent background works best, about 100 px tall is plenty).
It is shown small, on top of the name of anyone who has the bauna role. If the file is missing, only the "bauna" tag is shown.
Refresh the page (Ctrl+F5) after adding it.
