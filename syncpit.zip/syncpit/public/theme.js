/* SyncPit theme: follows the system (dark/light) until the person picks one with the moon/sun button.
   Loaded in <head> before the stylesheet so the page never flashes the wrong colours. */
(function () {
  "use strict";
  var KEY = "syncpit-theme", root = document.documentElement;
  var mq = window.matchMedia ? window.matchMedia("(prefers-color-scheme: light)") : null;
  function system() { return mq && mq.matches ? "light" : "dark"; }
  function stored() { try { var v = localStorage.getItem(KEY); return v === "light" || v === "dark" ? v : ""; } catch (e) { return ""; } }
  function apply(theme) {
    root.setAttribute("data-theme", theme);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", theme === "light" ? "#f5f5f7" : "#161618");
    var btn = document.getElementById("themeBtn");
    if (btn) {
      var next = theme === "light" ? "dark" : "light";
      btn.setAttribute("aria-label", "Switch to " + next + " theme");
      btn.setAttribute("title", "Switch to " + next + " theme");
    }
  }
  apply(stored() || system());
  // follow the system live, but only while the person has not chosen manually
  if (mq) {
    var onChange = function () { if (!stored()) apply(system()); };
    if (mq.addEventListener) mq.addEventListener("change", onChange); else if (mq.addListener) mq.addListener(onChange);
  }
  document.addEventListener("click", function (e) {
    var t = e.target; while (t && t !== document && t.id !== "themeBtn") t = t.parentNode;
    if (!t || t === document) return;
    var next = root.getAttribute("data-theme") === "light" ? "dark" : "light";
    try {
      // choosing the same theme the system already has goes back to "follow the system"
      if (next === system()) localStorage.removeItem(KEY); else localStorage.setItem(KEY, next);
    } catch (err) {}
    apply(next);
  });
  document.addEventListener("DOMContentLoaded", function () { apply(root.getAttribute("data-theme") || system()); });
})();
