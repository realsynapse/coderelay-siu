require("dotenv").config();
const express = require("express");
const http = require("http");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");
const { Server } = require("socket.io");
const QRCode = require("qrcode");
const { createClient } = require("@supabase/supabase-js");
const OT = require("./public/ot.js");

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 3000;

// ---------- limits ----------
const MAX_CODE_LENGTH = 80000;
const SAVE_DELAY_MS = 500;
const EVICT_AFTER_MS = 5 * 60 * 1000;
const ROOM_ID_RE = /^[A-Za-z0-9_-]{6,40}$/;
const CLIENT_ID_RE = /^[A-Za-z0-9-]{8,64}$/;
const MAX_PARTICIPANTS = 30;
const LOG_KEEP = 1000;          // ops kept to merge late edits
const HISTORY_MEMORY = 300;     // entries kept in memory per room
const HISTORY_KEEP_DB = 1000;   // entries kept in the database per room
const HISTORY_FIRST_PAGE = 50;
const COALESCE_MS = 8000;       // typing by one person within this window becomes one history entry
const SNIPPET_MAX_CHARS = 4000;
const SNIPPET_MAX_LINES = 60;
const ROLES = ["admin", "moderator", "bauna", "monster"];   // monster = top rank, same powers as the developer                       // the only roles that can be given; "developer" is never a role
const roleOf = (id, role) => (isDevId(id) ? null : ROLES.includes(role) ? role : null);
// Developer accounts: user #1 and user #6 have identical developer powers. DEVELOPER_USER_ID (optional, comma separated) can add more.
const DEV_IDS = new Set([1, 6, ...String(process.env.DEVELOPER_USER_ID || "").split(",").map(x => Number(x.trim())).filter(n => Number.isInteger(n) && n > 0)]);
const isDevId = id => DEV_IDS.has(Number(id));
const PALETTE = ["#e8a33d", "#3fb8af", "#6fa8ff", "#b58cff", "#7bd88f", "#ff7eb6", "#d4d46a", "#f08a5d"];

// ---------- encryption at rest (AES-256-GCM) ----------
const DEV_MEMORY = process.env.DEV_MEMORY_DB === "1";
function loadKey() {
  const raw = (process.env.ENCRYPTION_KEY || "").trim();
  if (!raw) return null;
  const buf = /^[0-9a-fA-F]{64}$/.test(raw) ? Buffer.from(raw, "hex") : Buffer.from(raw, "base64");
  return buf.length === 32 ? buf : null;
}
let KEY = loadKey();
if (!KEY) {
  if (DEV_MEMORY) {
    KEY = crypto.randomBytes(32);
    console.warn("[SyncPit] DEV mode: using a temporary encryption key. Data is kept in memory only.");
  } else {
    console.error("\n[SyncPit] ENCRYPTION_KEY is missing or not 32 bytes. Refusing to start without encryption at rest.");
    console.error("[SyncPit] Create one with:  node -e \"console.log(require('crypto').randomBytes(32).toString('base64'))\"");
    console.error("[SyncPit] Put it in .env (or your host's environment variables) as ENCRYPTION_KEY, and keep a backup: lost key = unreadable workspaces.\n");
    process.exit(1);
  }
}
const PREFIX = "enc:v1:";
function seal(text, aad) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", KEY, iv);
  c.setAAD(Buffer.from(aad));
  const ct = Buffer.concat([c.update(String(text), "utf8"), c.final()]);
  return PREFIX + Buffer.concat([iv, c.getAuthTag(), ct]).toString("base64");
}
function open(text, aad) {
  if (typeof text !== "string" || !text.startsWith(PREFIX)) return text || ""; // rows saved before encryption was added
  const buf = Buffer.from(text.slice(PREFIX.length), "base64");
  const d = crypto.createDecipheriv("aes-256-gcm", KEY, buf.subarray(0, 12));
  d.setAAD(Buffer.from(aad));
  d.setAuthTag(buf.subarray(12, 28));
  return Buffer.concat([d.update(buf.subarray(28)), d.final()]).toString("utf8");
}

// ---------- database (Supabase, or memory for local development) ----------
const isMissingTable = e => Boolean(e) && (e.code === "PGRST205" || e.code === "42P01" || /schema cache|does not exist/i.test(e.message || ""));
let warnedHistory = false;
function warnHistoryMissing() {
  if (warnedHistory) return; warnedHistory = true;
  console.error("\n[SyncPit] The table public.room_history does not exist yet, so change history is not being saved.");
  console.error("[SyncPit] Fix: Supabase > SQL Editor > paste supabase/schema.sql > Run. Your workspaces keep working meanwhile.\n");
}
function supabaseDb() {
  const c = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
  const chk = ({ error, data }) => { if (error) throw error; return data; };
  return {
    async getRoom(id) { return chk(await c.from("rooms").select("*").eq("id", id).maybeSingle()); },
    async upsertRoom(row) { chk(await c.from("rooms").upsert(row)); },
    async listHistory(id, beforeMs, limit) {
      let q = c.from("room_history").select("*").eq("room_id", id).order("ts", { ascending: false }).limit(limit);
      if (beforeMs) q = q.lt("ts", new Date(beforeMs).toISOString());
      const { data, error } = await q;
      if (error) { if (isMissingTable(error)) { warnHistoryMissing(); return []; } throw error; }
      return data || [];
    },
    async upsertHistory(rows) { if (rows.length) chk(await c.from("room_history").upsert(rows)); },
    async getUserByHash(h) {
      const u = chk(await c.from("users").select("id,name,role").eq("token_hash", h).maybeSingle());
      if (u) return u;
      const ss = await c.from("user_sessions").select("user_id").eq("token_hash", h).maybeSingle();     // a second browser/device signed in to the same account
      if (ss.error) { if (isMissingTable(ss.error)) return null; throw ss.error; }
      return ss.data ? chk(await c.from("users").select("id,name,role").eq("id", ss.data.user_id).maybeSingle()) : null;
    },
    // sign in with a provider (needs the auth_id / auth_provider columns and user_sessions table from schema.sql)
    async getUserByAuth(authId) { return chk(await c.from("users").select("id,name,role").eq("auth_id", authId).maybeSingle()); },
    async getAuthProvider(id) { const { data, error } = await c.from("users").select("auth_provider").eq("id", id).maybeSingle(); return error ? null : (data && data.auth_provider) || null; },
    async addSession(uid, h) { chk(await c.from("user_sessions").insert({ token_hash: h, user_id: uid })); },
    async deleteSession(h) { await c.from("user_sessions").delete().eq("token_hash", h); },
    async getNameInfo(id) { const r = chk(await c.from("users").select("name,name_changed_at").eq("id", id).maybeSingle()); return r ? { name: r.name, at: r.name_changed_at ? new Date(r.name_changed_at).getTime() : null } : null; },
    // changes the name only if the last change is older than the cutoff: one atomic statement, so two quick clicks can never both succeed
    async renameUser(id, name, iso, cutoffIso) {
      const { data, error } = await c.from("users").update({ name, name_changed_at: iso }).eq("id", id).or("name_changed_at.is.null,name_changed_at.lte." + cutoffIso).select("id");
      if (error) { if (error.code === "23505") throw Object.assign(new Error("taken"), { taken: true }); throw error; }
      return Boolean(data && data.length);
    },
    async linkAuth(uid, authId, provider) { chk(await c.from("users").update({ auth_id: authId, auth_provider: provider }).eq("id", uid).is("auth_id", null)); },
    async createAuthUser(h, name, authId, provider) {
      const { data, error } = await c.from("users").insert({ token_hash: h, name, auth_id: authId, auth_provider: provider }).select("id,name,role").single();
      if (error) { if (error.code === "23505") throw Object.assign(new Error("taken"), { taken: true }); throw error; }
      return data;
    },
    async getUserById(id) { return chk(await c.from("users").select("id,name,role").eq("id", id).maybeSingle()); },
    async setUserRole(id, role) { chk(await c.from("users").update({ role }).eq("id", id)); },
    async searchUsers(q) {
      const rows = new Map(), add = d => (d || []).forEach(r => rows.set(Number(r.id), r));
      if (/^#?\d{1,15}$/.test(q)) add(chk(await c.from("users").select("id,name,role").eq("id", Number(q.replace("#", ""))).limit(1)));
      add(chk(await c.from("users").select("id,name,role").ilike("name", "%" + q.replace(/[\\%_]/g, "\\$&") + "%").order("id").limit(10)));
      return [...rows.values()].slice(0, 10);
    },
    // workspace counts (need the creator_id / rooms_created columns from schema.sql)
    async getRoomsMeta(ids) { return chk(await c.from("rooms").select("id,code,language,locked,created_at,updated_at").in("id", ids)); },
    async roomsByCreator(uid, limit) { return chk(await c.from("rooms").select("id").eq("creator_id", uid).order("updated_at", { ascending: false }).limit(limit)).map(r => r.id); },
    async setRoomCreator(id, uid) { chk(await c.from("rooms").update({ creator_id: uid }).eq("id", id)); },
    async getCreated(ids) { const rows = chk(await c.from("users").select("id,rooms_created").in("id", ids)); return new Map(rows.map(r => [Number(r.id), Number(r.rooms_created) || 0])); },
    async bumpCreated(uid) {
      const r = chk(await c.from("users").select("rooms_created").eq("id", uid).maybeSingle());
      chk(await c.from("users").update({ rooms_created: (Number(r && r.rooms_created) || 0) + 1 }).eq("id", uid));
    },
    async countSaved(ids) {
      const out = new Map();
      await Promise.all(ids.map(async id => { const { count, error } = await c.from("rooms").select("id", { count: "exact", head: true }).eq("creator_id", id); if (error) throw error; out.set(id, count || 0); }));
      return out;
    },
    async topCreators(limit) { return chk(await c.from("users").select("id,name,role,rooms_created").gt("rooms_created", 0).order("rooms_created", { ascending: false }).limit(limit)); },
    async createUser(h, name) {
      const { data, error } = await c.from("users").insert({ token_hash: h, name }).select("id,name,role").single();
      if (error) { if (error.code === "23505") throw Object.assign(new Error("taken"), { taken: true }); throw error; }
      return data;
    },
    async nameTaken(name) {
      // PostgREST treats "*" as a wildcard, so "No*" would match "Noitsnot". Match "*" as any one character, then confirm an exact (case-insensitive) match here.
      const pat = name.replace(/[\\%_]/g, "\\$&").replace(/\*/g, "_");
      const rows = chk(await c.from("users").select("name").ilike("name", pat).limit(50));
      const k = name.toLowerCase();
      return rows.some(r => String(r.name).toLowerCase() === k);
    },
    async deleteRoom(id) {
      chk(await c.from("rooms").delete().eq("id", id));
      const h = await c.from("room_history").delete().eq("room_id", id);
      if (h.error && !isMissingTable(h.error)) throw h.error;
    },
    async pruneHistory(id, keep) {
      const r = await c.from("room_history").select("id").eq("room_id", id).order("ts", { ascending: false }).range(keep, keep + 499);
      if (r.error) { if (isMissingTable(r.error)) return; throw r.error; }
      if (r.data.length) chk(await c.from("room_history").delete().in("id", r.data.map(x => x.id)));
    }
  };
}
function memoryDb() {
  const rooms = new Map(), hist = new Map(), users = new Map(); let nextUser = 1;
  return {
    async getRoom(id) { return rooms.get(id) || null; },
    async upsertRoom(row) { rooms.set(row.id, { ...row }); },
    async listHistory(id, beforeMs, limit) {
      return [...(hist.get(id) || new Map()).values()].filter(r => !beforeMs || new Date(r.ts).getTime() < beforeMs)
        .sort((a, b) => new Date(b.ts) - new Date(a.ts)).slice(0, limit);
    },
    async upsertHistory(rows) { for (const r of rows) { if (!hist.has(r.room_id)) hist.set(r.room_id, new Map()); hist.get(r.room_id).set(r.id, { ...r }); } },
    async getUserByHash(h) { return users.get(h) || null; },
    async getUserByAuth() { return null; },                     // provider sign-in needs Supabase
    async getAuthProvider() { return null; },
    async addSession() { throw new Error("Sign-in needs Supabase"); },
    async deleteSession() {},
    async getNameInfo(id) { const u = [...users.values()].find(x => x.id === id); return u ? { name: u.name, at: u.name_changed_at || null } : null; },
    async renameUser(id, name, iso, cutoffIso) {
      const u = [...users.values()].find(x => x.id === id); if (!u) return false;
      if (u.name_changed_at && u.name_changed_at > new Date(cutoffIso).getTime()) return false;
      if ([...users.values()].some(x => x.id !== id && x.name.toLowerCase() === name.toLowerCase())) throw Object.assign(new Error("taken"), { taken: true });
      u.name = name; u.name_changed_at = new Date(iso).getTime(); return true;
    },
    async linkAuth() { throw new Error("Sign-in needs Supabase"); },
    async createAuthUser() { throw new Error("Sign-in needs Supabase"); },
    async getUserById(id) { return [...users.values()].find(u => u.id === id) || null; },
    async setUserRole(id, role) { const u = [...users.values()].find(x => x.id === id); if (u) u.role = role; },
    async searchUsers(q) {
      const k = q.toLowerCase(), n = /^#?\d{1,15}$/.test(q) ? Number(q.replace("#", "")) : null;
      return [...users.values()].filter(u => u.id === n || u.name.toLowerCase().includes(k)).slice(0, 10).map(u => ({ id: u.id, name: u.name, role: u.role || null }));
    },
    async nameTaken(name) { return [...users.values()].some(u => u.name.toLowerCase() === name.toLowerCase()); },
    async createUser(h, name) {
      if (await this.nameTaken(name)) throw Object.assign(new Error("taken"), { taken: true });
      const row = { id: nextUser++, name, role: null }; users.set(h, row); return row;
    },
    async getRoomsMeta(ids) { return ids.map(id => rooms.get(id)).filter(Boolean); },
    async roomsByCreator(uid, limit) { return [...rooms.values()].filter(r => r.creator_id === uid).slice(0, limit).map(r => r.id); },
    async setRoomCreator(id, uid) { const r = rooms.get(id); if (r) r.creator_id = uid; },
    async getCreated(ids) { return new Map(ids.map(id => { const u = [...users.values()].find(x => x.id === id); return [id, u ? u.rooms_created || 0 : 0]; })); },
    async bumpCreated(uid) { const u = [...users.values()].find(x => x.id === uid); if (u) u.rooms_created = (u.rooms_created || 0) + 1; },
    async countSaved(ids) { return new Map(ids.map(id => [id, [...rooms.values()].filter(r => r.creator_id === id).length])); },
    async topCreators(limit) { return [...users.values()].filter(u => (u.rooms_created || 0) > 0).sort((a, b) => b.rooms_created - a.rooms_created).slice(0, limit).map(u => ({ id: u.id, name: u.name, role: u.role || null, rooms_created: u.rooms_created })); },
    async pruneHistory() {},
    async deleteRoom(id) { rooms.delete(id); hist.delete(id); }
  };
}
const db = process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY ? supabaseDb() : DEV_MEMORY ? memoryDb() : null;
if (!db) {
  console.error("\n[SyncPit] SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY are not set.");
  console.error("[SyncPit] Copy .env.example to .env and fill them in. Workspaces cannot be created until then.\n");
}

// ---------- hardening: proxy, https, headers ----------
app.disable("x-powered-by");
if (process.env.TRUST_PROXY) app.set("trust proxy", Number(process.env.TRUST_PROXY) || 1);
else if (process.env.RENDER) app.set("trust proxy", 1);   // on Render every request comes through its proxy; without this all visitors share one rate-limit bucket
app.use((req, res, next) => {
  if (process.env.FORCE_HTTPS === "1" && !req.secure) return res.redirect(308, "https://" + req.headers.host + req.originalUrl);
  next();
});
const hostOk = h => /^[A-Za-z0-9.\-:\[\]]{1,255}$/.test(h || "");
app.use((req, res, next) => {
  res.set({
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",               // room links are secrets; never leak them in Referer
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Resource-Policy": "same-origin"
  });
  if (req.secure) res.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  if (req.path === "/runner") {
    // The runner executes teammates' code. It is sandboxed into an opaque origin: no cookies,
    // no localStorage, no access to this site, and no network except the Python runtime CDN.
    res.set({
      "X-Frame-Options": "SAMEORIGIN",
      "Content-Security-Policy": [
        "sandbox allow-scripts", "default-src 'none'",
        "script-src 'unsafe-inline' 'unsafe-eval' 'wasm-unsafe-eval' blob: https://cdn.jsdelivr.net",
        "worker-src blob:", "connect-src https://cdn.jsdelivr.net", "style-src 'unsafe-inline'",
        "img-src data: blob: https:", "font-src data:", "frame-src about: blob: data:", "frame-ancestors 'self'"
      ].join("; ")
    });
  } else {
    const h = hostOk(req.headers.host) ? req.headers.host : "localhost";
    res.set({
      "X-Frame-Options": "DENY",
      "Content-Security-Policy": [
        "default-src 'self'", "script-src 'self'", "style-src 'self' 'unsafe-inline'",
        "img-src 'self' data:", `connect-src 'self' ws://${h} wss://${h}`,
        "frame-src 'self'", "object-src 'none'", "base-uri 'none'", "form-action 'self'", "frame-ancestors 'none'"
      ].join("; ")
    });
  }
  next();
});
app.use(express.json({ limit: "100kb" }));

// ---------- maintenance mode (developer only) ----------
// off -> warning (countdown, owners are told to save their owner link) -> on (everyone except the developer sees the unavailable page).
// The state lives in memory: a server restart turns maintenance off.
const maint = { phase: "off", endsAt: 0, timer: null, by: "" };
const maintPublic = () => ({ phase: maint.phase, endsAt: maint.endsAt, now: Date.now(), by: maint.by });
const isDevUser = u => Boolean(u) && (isDevId(u.id) || u.role === "monster");
const isStaff = isDevUser;   // only the developer (#1) runs maintenance mode and can still open the site during it
const MAINT_PAGE = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="60"><meta name="color-scheme" content="light dark"><title>Temporarily unavailable</title>
<style>body{margin:0;padding:12vh 24px 24px;font:15px/1.6 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}main{max-width:600px;margin:0 auto}.i{font-size:56px;opacity:.55;margin-bottom:12px}h1{font-size:24px;font-weight:500;margin:0 0 12px}p{margin:0 0 10px;opacity:.75}.c{font-size:12px;opacity:.6}button{margin-top:18px;font:inherit;padding:6px 14px}</style></head>
<body><main><div class="i">:(</div><h1>This site is temporarily unavailable</h1><p>SyncPit is under maintenance. It will be back in a little while. Please try again in a few minutes.</p><p class="c">Error code: 503 Service Unavailable</p><form method="get" action=""><button>Reload</button></form></main></body></html>`;
app.use(async (req, res, next) => {
  if (maint.phase !== "on") return next();
  if (req.path === "/health" || req.path === "/api/status") return next();      // the host's health check must keep passing
  try { if (req.headers.cookie && isStaff(await userFromCookie(req.headers.cookie))) return next(); } catch {}   // staff can still open the site to turn maintenance off
  res.set({ "Cache-Control": "no-store", "Retry-After": "300" });
  if (req.path.startsWith("/api/")) return res.status(503).json({ error: "The site is under maintenance. Please try again soon.", maintenance: true });
  res.status(503).type("html").send(MAINT_PAGE);
});
app.get("/api/status", (_req, res) => { res.set("Cache-Control", "no-store"); res.json({ maintenance: maint.phase === "on" }); });
async function goMaintenance() {
  maint.timer = null;
  await Promise.allSettled([...rooms].map(([id, room]) => flushRoom(id, room)));      // save every workspace before going down
  if (maint.phase !== "warning") return;                                               // cancelled while saving
  maint.phase = "on"; maint.endsAt = 0;
  io.emit("maintenance", maintPublic());
  setTimeout(async () => {
    for (const sock of [...io.sockets.sockets.values()]) {
      let dev = false;
      try { dev = isStaff(await userFromCookie(sock.request.headers.cookie)); } catch {}
      if (!dev) sock.disconnect(true);
    }
  }, 2500).unref();
}
function setMaintenance(action, seconds, by) {
  clearTimeout(maint.timer); maint.timer = null;
  if (action === "start") {
    const secs = [0, 30, 60, 120, 300].includes(Number(seconds)) ? Number(seconds) : 60;
    maint.by = String(by || "").slice(0, 60);
    maint.phase = "warning"; maint.endsAt = Date.now() + secs * 1000;
    if (secs === 0) { goMaintenance(); return; }                    // right now, no warning: saves every workspace, then goes live
    maint.timer = setTimeout(goMaintenance, secs * 1000);
  } else { maint.phase = "off"; maint.endsAt = 0; maint.by = ""; }
  io.emit("maintenance", maintPublic());
}

// ---------- rate limiting (no extra dependency) ----------
const mkBucket = (rate, burst) => ({ rate, burst, tokens: burst, last: Date.now() });
function take(b) {
  const now = Date.now();
  b.tokens = Math.min(b.burst, b.tokens + ((now - b.last) / 1000) * b.rate);
  b.last = now;
  if (b.tokens >= 1) { b.tokens -= 1; return true; }
  return false;
}
const ipBuckets = new Map();
function ipLimit(name, rate, burst) {
  return (req, res, next) => {
    const k = name + ":" + req.ip;
    let e = ipBuckets.get(k);
    if (!e) ipBuckets.set(k, e = { b: mkBucket(rate, burst), seen: Date.now() });
    e.seen = Date.now();
    if (!take(e.b)) return res.status(429).json({ error: "Too many requests. Please wait a moment and try again." });
    next();
  };
}
setInterval(() => { const cut = Date.now() - 10 * 60 * 1000; for (const [k, e] of ipBuckets) if (e.seen < cut) ipBuckets.delete(k); }, 60000).unref();

// ---------- favicon (auto-detected from ./favicon) ----------
const FAVICON_DIR = path.join(__dirname, "favicon");
const FAVICON_TYPES = { ".ico": "image/x-icon", ".png": "image/png", ".svg": "image/svg+xml", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp" };
const DEFAULT_FAVICON = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="#1f1f23"/><g fill="none" stroke="#d9303e" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"><path d="M25 20 13 32l12 12"/><path d="M39 20l12 12-12 12"/></g></svg>`;
function findFavicon() {
  try {
    const files = fs.readdirSync(FAVICON_DIR)
      .filter(f => !f.startsWith(".") && FAVICON_TYPES[path.extname(f).toLowerCase()])
      .sort((a, b) => Number(b.toLowerCase().startsWith("favicon")) - Number(a.toLowerCase().startsWith("favicon")) || a.localeCompare(b));
    return files.length ? path.join(FAVICON_DIR, files[0]) : null;
  } catch { return null; }
}
app.get(["/favicon", "/favicon.ico"], (_req, res) => {
  res.set("Cache-Control", "no-cache");
  const file = findFavicon();
  if (file) return res.type(FAVICON_TYPES[path.extname(file).toLowerCase()]).sendFile(file);
  res.type("image/svg+xml").send(DEFAULT_FAVICON);
});
app.get("/runner", (_req, res) => { res.set("Cache-Control", "no-store"); res.sendFile(path.join(__dirname, "views", "runner.html")); });
app.use(express.static(path.join(__dirname, "public"), { index: "index.html" }));

// ---------- helpers ----------
const rooms = new Map();
const loading = new Map();
const tokenHash = token => crypto.createHash("sha256").update(String(token || "")).digest();
function isOwnerToken(room, token) {
  if (!room || typeof token !== "string" || !token || token.length > 200) return false;
  const actual = tokenHash(token);
  return actual.length === room.ownerTokenHash.length && crypto.timingSafeEqual(actual, room.ownerTokenHash);
}
const lineIndex = (doc, pos) => { let n = 0, i = -1; while ((i = doc.indexOf("\n", i + 1)) !== -1 && i < pos) n++; return n; };
const cleanName = s => String(s || "").replace(/[\u0000-\u001f\u007f<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 24);
const aidOf = (clientId, roomId) => crypto.createHash("sha256").update(clientId + ":" + roomId).digest("hex").slice(0, 10);

function pickColor(room, clientId) {
  const used = new Set([...room.sockets].map(s => io.sockets.sockets.get(s)?.data.author?.color));
  let h = 0; for (const ch of clientId) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  for (let i = 0; i < PALETTE.length; i++) { const c = PALETTE[(h + i) % PALETTE.length]; if (!used.has(c)) return c; }
  return PALETTE[h % PALETTE.length];
}
function peersOf(room) {
  const out = [];
  for (const sid of room.sockets) {
    const s = io.sockets.sockets.get(sid);
    if (s && s.data.author) out.push({ pid: sid, aid: s.data.author.aid, uid: s.data.author.uid, dev: isDevId(s.data.author.uid), role: roleOf(s.data.author.uid, s.data.author.role), name: s.data.author.name, color: s.data.author.color, owner: Boolean(s.data.isOwner), cursor: s.data.cursor || null });
  }
  return out;
}
const entryOut = e => ({ id: e.id, ts: e.ts, aid: e.aid, author: e.author, color: e.color, kind: e.kind, start: e.start, end: e.end, before: e.before, after: e.after, trunc: e.trunc, reverted: e.reverted || false });
function publicState(id, room, socket) {
  return {
    id, code: room.code, language: room.language, rev: room.rev, locked: room.locked,
    isOwner: Boolean(socket.data.isOwner), you: { pid: socket.id, aid: socket.data.author.aid, name: socket.data.author.name, color: socket.data.author.color, dev: isDevId(socket.data.author.uid), role: roleOf(socket.data.author.uid, socket.data.author.role) },
    peers: peersOf(room), history: room.history.slice(-HISTORY_FIRST_PAGE).map(entryOut).reverse(), historyTotal: room.history.length
  };
}

// ---------- persistence ----------
const rowToEntry = r => {
  let p = {}; try { p = JSON.parse(open(r.payload || "", r.room_id + ":h") || "{}"); } catch { p = {}; }
  return { id: r.id, ts: new Date(r.ts).getTime(), aid: r.author_id, author: r.author, color: r.color, kind: r.kind, start: r.start_line, end: r.end_line,
    before: p.before || "", after: p.after || "", trunc: Boolean(p.trunc), reverted: Boolean(p.reverted) };
};
const entryToRow = (roomId, e) => ({
  id: e.id, room_id: roomId, ts: new Date(e.ts).toISOString(), author: e.author, author_id: e.aid, color: e.color, kind: e.kind,
  start_line: e.start, end_line: e.end, payload: seal(JSON.stringify({ before: e.before, after: e.after, trunc: e.trunc, reverted: e.reverted || false }), roomId + ":h"),
  updated_at: new Date().toISOString()
});

async function loadRoom(id) {
  if (rooms.has(id)) return rooms.get(id);
  if (!db || !ROOM_ID_RE.test(id)) return null;
  if (loading.has(id)) return loading.get(id);
  const job = (async () => {
    const data = await db.getRoom(id);
    if (!data) return null;
    const cached = rooms.get(id); if (cached) return cached;
    const hist = (await db.listHistory(id, null, HISTORY_MEMORY)).map(rowToEntry).sort((a, b) => a.ts - b.ts);
    const room = {
      code: open(data.code, id), language: data.language, locked: data.locked,
      ownerTokenHash: Buffer.from(data.owner_token_hash, "hex"), createdAt: new Date(data.created_at).getTime(),
      rev: 0, log: [], lens: [], logStart: 0, sockets: new Set(), history: hist, open: null, entrySeq: 0, newEntries: 0,
      dirty: false, dirtyEntries: new Map(), pendingBroadcast: new Map(), histTimer: null, saveTimer: null, evictTimer: null,
      creatorId: data.creator_id == null ? null : Number(data.creator_id)
    };
    rooms.set(id, room);
    return room;
  })().finally(() => loading.delete(id));
  loading.set(id, job);
  return job;
}
const newRoomObject = (code, language, ownerToken) => ({
  creatorId: null, code, language, ownerTokenHash: tokenHash(ownerToken), locked: false, createdAt: Date.now(),
  rev: 0, log: [], lens: [], logStart: 0, sockets: new Set(), history: [], open: null, entrySeq: 0, newEntries: 0,
  dirty: false, dirtyEntries: new Map(), pendingBroadcast: new Map(), histTimer: null, saveTimer: null, evictTimer: null
});
async function saveRoom(id, room) {
  await db.upsertRoom({
    id, code: seal(room.code, id), language: room.language, locked: room.locked,
    owner_token_hash: room.ownerTokenHash.toString("hex"), updated_at: new Date().toISOString()
  });
}
function scheduleSave(id, room, delay = SAVE_DELAY_MS) {
  if (!db) return;
  room.dirty = true;
  clearTimeout(room.saveTimer);
  room.saveTimer = setTimeout(() => flushRoom(id, room), delay);
}
async function flushRoom(id, room) {
  clearTimeout(room.saveTimer);
  if (room.deleted || !db || (!room.dirty && room.dirtyEntries.size === 0)) return;
  const entries = [...room.dirtyEntries.values()], wasDirty = room.dirty;
  room.dirty = false; room.dirtyEntries = new Map();
  let retry = false;
  if (wasDirty) {
    try { await saveRoom(id, room); }
    catch (err) { console.error(`[SyncPit] Save failed for room ${id}:`, err.message || err); room.dirty = true; retry = true; }
  }
  if (entries.length) {
    try { await db.upsertHistory(entries.map(e => entryToRow(id, e))); if (room.newEntries >= 40) { room.newEntries = 0; await db.pruneHistory(id, HISTORY_KEEP_DB); } }
    catch (err) {
      if (isMissingTable(err)) warnHistoryMissing();      // history can't be stored yet; the workspace itself still saves
      else { console.error(`[SyncPit] History save failed for room ${id}:`, err.message || err); for (const e of entries) room.dirtyEntries.set(e.id, e); retry = true; }
    }
  }
  if (retry) room.saveTimer = setTimeout(() => flushRoom(id, room), 3000);
}
function maybeEvict(id, room) {
  clearTimeout(room.evictTimer);
  if (room.sockets.size > 0) return;
  room.evictTimer = setTimeout(async () => {
    if (room.sockets.size > 0) return;
    await flushRoom(id, room);
    if (!room.dirty && room.dirtyEntries.size === 0 && room.sockets.size === 0) rooms.delete(id);
  }, EVICT_AFTER_MS);
}
const flushAll = () => Promise.all([...rooms].map(([id, room]) => flushRoom(id, room)));

// ---------- history ----------
function snippet(doc, from, to) {
  const lines = doc.split("\n").slice(from, to + 1);
  let trunc = false;
  if (lines.length > SNIPPET_MAX_LINES) { lines.length = SNIPPET_MAX_LINES; trunc = true; }
  let s = lines.join("\n");
  if (s.length > SNIPPET_MAX_CHARS) { s = s.slice(0, SNIPPET_MAX_CHARS); trunc = true; }
  return { text: s, trunc };
}
// Lines of `after` that differ from `base`, expanded to whole lines.
function region(base, after) {
  const [h] = OT.hunks(base, OT.fromDiff(base, after));
  if (!h) return null;
  const bFrom = lineIndex(base, h.pos), bTo = lineIndex(base, h.pos + h.del.length);
  const aFrom = lineIndex(after, h.pos), aTo = lineIndex(after, h.pos + h.ins.length);
  const b = snippet(base, bFrom, bTo), a = snippet(after, aFrom, aTo);
  return { start: aFrom + 1, end: aTo + 1, before: b.text, after: a.text, trunc: b.trunc || a.trunc };
}
function touch(room, e) {
  room.entrySeq++; e.seq = room.entrySeq; e.updated = Date.now();
  room.dirtyEntries.set(e.id, e);
}
function addEntry(room, e) {
  room.history.push(e);
  if (room.history.length > HISTORY_MEMORY) room.history.shift();
  room.newEntries++;
  touch(room, e);
}
function closeOpen(room) { if (room.open) { delete room.open.base; room.open = null; } }
function recordEdit(id, room, author, oldDoc, op) {
  let cur = oldDoc;
  for (const h of OT.hunks(oldDoc, op)) {
    const next = cur.slice(0, h.pos) + h.ins + cur.slice(h.pos + h.del.length);
    const now = Date.now(), open = room.open;
    const first = lineIndex(cur, h.pos), last = lineIndex(cur, h.pos + h.del.length);   // 0-based lines touched
    const mergeable = open && open.aid === author.aid && open.seq === room.entrySeq && now - open.updated <= COALESCE_MS &&
      first <= open.end + 1 && last >= open.start - 3;                                  // within 2 lines of that entry
    if (mergeable) {
      const r = region(open.base, next);
      if (!r) { // typed and deleted again: nothing changed overall
        room.history = room.history.filter(x => x !== open); room.dirtyEntries.delete(open.id);
        room.pendingBroadcast.set(open.id, { id: open.id, gone: true });
        room.open = null; room.entrySeq++;
      } else { Object.assign(open, r); touch(room, open); queueHistory(id, room, open); }
    } else {
      closeOpen(room);
      const r = region(cur, next);
      if (r) {
        const e = { id: crypto.randomUUID(), ts: now, aid: author.aid, author: author.name, color: author.color, kind: "edit", base: cur, ...r };
        addEntry(room, e); room.open = e; queueHistory(id, room, e);
      }
    }
    cur = next;
  }
}
// History updates are sent at most every 400 ms per workspace, so fast typing doesn't flood everyone.
function queueHistory(id, room, entry) {
  room.pendingBroadcast.set(entry.id, entry);
  if (room.histTimer) return;
  room.histTimer = setTimeout(() => {
    room.histTimer = null;
    const items = [...room.pendingBroadcast.values()]; room.pendingBroadcast = new Map();
    for (const e of items) io.to(id).emit(e.gone ? "history-gone" : "history-entry", e.gone ? { id: e.id } : entryOut(e));
  }, 400);
}
function systemEntry(room, author, kind, before, after) {
  const e = { id: crypto.randomUUID(), ts: Date.now(), aid: author.aid, author: author.name, color: author.color, kind, start: 0, end: 0, before: before || "", after: after || "", trunc: false };
  closeOpen(room); addEntry(room, e);
  return e;
}

// ---------- applying operations ----------
function commitOp(id, room, author, op, exceptSocket) {
  const oldDoc = room.code;
  const newDoc = OT.apply(oldDoc, op);
  room.code = newDoc;
  room.log.push(op); room.lens.push(oldDoc.length); room.rev++;
  if (room.log.length > LOG_KEEP) { room.log.shift(); room.lens.shift(); room.logStart++; }
  for (const sid of room.sockets) {
    const s = io.sockets.sockets.get(sid);
    if (s && s.data.cursor) s.data.cursor = { a: OT.transformIndex(s.data.cursor.a, op, false), b: OT.transformIndex(s.data.cursor.b, op, false) };
  }
  recordEdit(id, room, author, oldDoc, op);
  scheduleSave(id, room);
  const payload = { rev: room.rev, op, pid: exceptSocket ? exceptSocket.id : null, aid: author.aid };
  if (exceptSocket) exceptSocket.to(id).emit("op", payload); else io.to(id).emit("op", payload);
  return room.rev;
}
function broadcastHistory(id, entry) { queueHistory(id, rooms.get(id), entry); }

// ---------- HTTP API ----------
app.get("/health", (_req, res) => res.json({ ok: true }));
// ---------- workspace counts: created (ever), saved (still exist), active (someone is in it right now) ----------
let statsWarned = false;
function statsFail(err) { if (!statsWarned) { statsWarned = true; console.error("[SyncPit] Workspace counts need the new columns. Fix: Supabase > SQL Editor > run supabase/schema.sql again. (" + (err && err.message || err) + ")"); } }
const activeBy = uid => { let n = 0; for (const r of rooms.values()) if (r.creatorId === uid && r.sockets.size > 0) n++; return n; };
async function statsFor(ids) {
  const out = {}; ids.forEach(id => { out[id] = { created: null, saved: null, active: activeBy(id) }; });
  if (!ids.length || !db) return out;
  try {
    const [made, kept] = await Promise.all([db.getCreated(ids), db.countSaved(ids)]);
    for (const id of ids) { const saved = kept.get(id) || 0; out[id].saved = saved; out[id].created = Math.max(made.get(id) || 0, saved); }
  } catch (err) { statsFail(err); }
  return out;
}
let creatorChain = Promise.resolve();
function recordCreator(id, uid) {                               // one at a time so the running total never loses a count
  creatorChain = creatorChain.then(async () => { try { await db.setRoomCreator(id, uid); await db.bumpCreated(uid); } catch (err) { statsFail(err); } });
}
app.post("/api/rooms", ipLimit("create", 20 / 3600, 10), async (req, res) => {
  res.set("Cache-Control", "no-store");
  if (!sameOrigin(req)) return res.status(403).json({ error: "Not allowed." });
  if (!db) return res.status(503).json({ error: "Database is not configured on the server." });
  const code = typeof req.body.code === "string" ? req.body.code : "";
  const language = typeof req.body.language === "string" ? req.body.language.slice(0, 60) : "Plain text";
  if (code.length > MAX_CODE_LENGTH) return res.status(413).json({ error: "Code is too large. Maximum is 80,000 characters." });
  const id = crypto.randomBytes(16).toString("base64url");
  const ownerToken = crypto.randomBytes(32).toString("base64url");
  const room = newRoomObject(code, language, ownerToken);
  try { await saveRoom(id, room); }
  catch (err) { console.error("[SyncPit] Create failed:", err.message || err); return res.status(500).json({ error: "Could not save the workspace. Please try again." }); }
  rooms.set(id, room);
  const maker = await userFromCookie(req.headers.cookie).catch(() => null);
  if (maker) { room.creatorId = maker.id; recordCreator(id, maker.id); }
  res.json({ id, ownerToken, shareUrl: `/room/${id}` });
});
// "My saved workspaces": the browser sends the workspace ids it holds an owner key for; the server adds the ones this person created.
// Knowing an id is the same as having its link, so listing details for ids the caller supplies reveals nothing new.
const previewOf = code => (String(code || "").split("\n").map(l => l.trim()).find(Boolean) || "").slice(0, 70);
app.post("/api/rooms/mine", ipLimit("mine", 1, 10), async (req, res) => {
  res.set("Cache-Control", "no-store");
  if (!sameOrigin(req)) return res.status(403).json({ error: "Not allowed." });
  if (!db) return res.status(503).json({ error: "Database is not configured on the server." });
  const asked = Array.isArray(req.body && req.body.ids) ? req.body.ids.filter(x => typeof x === "string" && ROOM_ID_RE.test(x)).slice(0, 50) : [];
  try {
    const user = await userFromCookie(req.headers.cookie).catch(() => null);
    let made = [];
    if (user) { try { made = await db.roomsByCreator(user.id, 50); } catch (err) { statsFail(err); } }
    const madeSet = new Set(made), ids = [...new Set([...made, ...asked])].slice(0, 80);
    const list = ids.length ? await db.getRoomsMeta(ids) : [];
    const out = list.map(row => {
      const live = rooms.get(row.id);
      let code = ""; try { code = live ? live.code : open(row.code, row.id); } catch {}
      return {
        id: row.id, language: String((live ? live.language : row.language) || "Plain text").slice(0, 60), locked: Boolean(live ? live.locked : row.locked),
        createdAt: row.created_at ? new Date(row.created_at).getTime() : null,
        updatedAt: live && live.dirty ? Date.now() : (row.updated_at ? new Date(row.updated_at).getTime() : null),
        active: live ? live.sockets.size : 0, preview: previewOf(code), mine: madeSet.has(row.id)
      };
    }).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    res.json({ rooms: out });
  } catch (err) { console.error("[SyncPit] My workspaces failed:", err.message || err); res.status(500).json({ error: "Could not load your workspaces." }); }
});
app.get("/api/qr", ipLimit("qr", 2, 20), async (req, res) => {
  const target = String(req.query.url || "");
  try {
    const parsed = new URL(target);
    if (!["http:", "https:"].includes(parsed.protocol) || parsed.host !== req.get("host")) return res.status(400).json({ error: "Invalid workspace URL." });
    const svg = await QRCode.toString(target, { type: "svg", margin: 1, width: 240, color: { dark: "#161618", light: "#ffffff" } });
    res.set("Cache-Control", "no-store").type("image/svg+xml").send(svg);
  } catch { res.status(400).json({ error: "Could not create QR code." }); }
});
// ---------- users: no login, just a name and a long-lived session cookie ----------
function parseCookies(h) { const o = {}; String(h || "").split(";").forEach(p => { const i = p.indexOf("="); if (i > 0) o[p.slice(0, i).trim()] = p.slice(i + 1).trim(); }); return o; }
const userCache = new Map();
async function userFromCookie(header) {
  const t = parseCookies(header).cr_session;
  if (!db || !t || !/^[A-Za-z0-9_-]{40,60}$/.test(t)) return null;
  const h = tokenHash(t).toString("hex");
  if (userCache.has(h)) return userCache.get(h);
  const row = await db.getUserByHash(h);
  if (!row) return null;
  const u = { id: Number(row.id), name: row.name, dev: isDevId(row.id), role: roleOf(row.id, row.role) };
  if (userCache.size > 5000) userCache.clear();
  userCache.set(h, u);
  return u;
}
const sameOrigin = req => { const o = req.headers.origin; if (!o) return true; try { return new URL(o).host === req.headers.host; } catch { return false; } };
app.get("/api/me", async (req, res) => {
  res.set("Cache-Control", "no-store");
  try {
    const u = await userFromCookie(req.headers.cookie);
    res.json({ user: u ? { ...u, provider: await db.getAuthProvider(u.id).catch(() => null) } : null });
  } catch { res.status(500).json({ error: "Could not load your profile." }); }
});
app.get("/api/name-available", ipLimit("namecheck", 5, 20), async (req, res) => {
  res.set("Cache-Control", "no-store");
  const name = cleanName(req.query.name);
  if (!name) return res.json({ valid: false, available: false });
  try { res.json({ valid: true, available: !(await db.nameTaken(name)) }); } catch { res.status(500).json({ error: "Could not check that name." }); }
});
app.post("/api/me", ipLimit("user", 20 / 3600, 10), async (req, res) => {
  res.set("Cache-Control", "no-store");
  if (!db) return res.status(503).json({ error: "Database is not configured on the server." });
  if (!sameOrigin(req)) return res.status(403).json({ error: "Not allowed." });
  try {
    if (await userFromCookie(req.headers.cookie)) return res.status(409).json({ error: "You already have a name. Names can't be changed." });
    const name = cleanName(req.body && req.body.name);
    if (!name) return res.status(400).json({ error: "Please enter a name." });
    if (await db.nameTaken(name)) return res.status(409).json({ error: "That name is already taken. Please choose another.", taken: true });
    const token = crypto.randomBytes(32).toString("base64url");
    const row = await db.createUser(tokenHash(token).toString("hex"), name);
    res.append("Set-Cookie", `cr_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=315360000${req.secure ? "; Secure" : ""}`);
    res.json({ user: { id: Number(row.id), name: row.name, dev: isDevId(row.id), role: roleOf(row.id, row.role) } });
  } catch (err) {
    if (err && err.taken) return res.status(409).json({ error: "That name is already taken. Please choose another.", taken: true });
    console.error("[SyncPit] Create user failed:", err.message || err); res.status(500).json({ error: "Could not save your name. Please try again." }); }
});
// ---------- sign in with Google / GitHub / ... (Supabase Auth, PKCE, everything on the server) ----------
// The browser only follows redirects. The one-time code is swapped for the person's identity here, so no provider keys or tokens reach the page.
// Turn it on with AUTH_PROVIDERS=google,github in Render (and enable those providers in Supabase). Without it, SyncPit works exactly as before.
const AUTH_LABELS = { google: "Google", github: "GitHub", discord: "Discord", azure: "Microsoft", twitter: "X", facebook: "Facebook", apple: "Apple", linkedin_oidc: "LinkedIn", gitlab: "GitLab", twitch: "Twitch" };
const AUTH_ON = String(process.env.AUTH_PROVIDERS || "").split(",").map(x => x.trim().toLowerCase()).filter(p => AUTH_LABELS[p]);
const authKey = () => process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || "";
// Google can sign in directly (no Supabase in between), so Google's screen shows YOUR address instead of ...supabase.co.
// Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET (from Google Cloud) in Render. Other providers still go through Supabase Auth.
const googleDirect = () => Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
const supaAuthOk = () => Boolean(process.env.SUPABASE_URL && authKey());
const providerReady = p => Boolean(db) && AUTH_ON.includes(p) && (p === "google" && googleDirect() ? true : supaAuthOk());
const authReady = () => AUTH_ON.some(providerReady);
const siteOrigin = req => String(process.env.PUBLIC_URL || (req.protocol + "://" + req.get("host"))).replace(/\/+$/, "");
const SESSION_COOKIE = (token, req) => `cr_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=315360000${req.secure ? "; Secure" : ""}`;
const flowCookie = (name, value, req, age) => `${name}=${value}; Path=/auth; HttpOnly; SameSite=Lax; Max-Age=${age}${req.secure ? "; Secure" : ""}`;
const SAFE_NEXT = /^\/room\/[A-Za-z0-9_-]{6,40}$/;
app.get("/api/auth/providers", (_req, res) => { res.set("Cache-Control", "no-store"); res.json({ providers: AUTH_ON.filter(providerReady).map(id => ({ id, label: AUTH_LABELS[id] })) }); });
app.get("/auth/login/:provider", ipLimit("auth-login", 1, 10), (req, res) => {
  res.set("Cache-Control", "no-store");
  const provider = String(req.params.provider || "").toLowerCase();
  if (!providerReady(provider)) return res.redirect(302, "/?login=off");
  const verifier = crypto.randomBytes(48).toString("base64url");
  const challenge = crypto.createHash("sha256").update(verifier).digest("base64url");
  const next = SAFE_NEXT.test(String(req.query.next || "")) ? String(req.query.next) : "";
  res.append("Set-Cookie", flowCookie("sp_pkce", verifier, req, 600));
  res.append("Set-Cookie", flowCookie("sp_next", next ? next.slice(1).replace("/", "_") : "", req, next ? 600 : 0));
  if (provider === "google" && googleDirect()) {                       // straight to Google; only the name is asked for (no email)
    const state = crypto.randomBytes(24).toString("base64url");
    res.append("Set-Cookie", flowCookie("sp_state", state, req, 600));
    return res.redirect(302, "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + encodeURIComponent(process.env.GOOGLE_CLIENT_ID)
      + "&redirect_uri=" + encodeURIComponent(siteOrigin(req) + "/auth/callback") + "&response_type=code&scope=" + encodeURIComponent("openid profile")
      + "&state=" + state + "&code_challenge=" + challenge + "&code_challenge_method=S256&prompt=select_account");
  }
  const url = process.env.SUPABASE_URL.replace(/\/+$/, "") + "/auth/v1/authorize?provider=" + encodeURIComponent(provider)
    + "&redirect_to=" + encodeURIComponent(siteOrigin(req) + "/auth/callback") + "&code_challenge=" + challenge + "&code_challenge_method=s256";
  res.redirect(302, url);
});
const profileName = su => { const m = su.user_metadata || {}; return cleanName(m.full_name || m.name || m.user_name || m.preferred_username || m.nickname || "") || "Coder"; };   // never the email
async function freeName(base) {
  for (let i = 0; i < 30; i++) { const n = i ? cleanName(base.slice(0, 20) + " " + (i + 1)) : base; if (!(await db.nameTaken(n))) return n; }
  return cleanName(base.slice(0, 16) + " " + crypto.randomInt(1000, 9999));
}
async function signInWith(su, req, res) {
  const provider = String((su.app_metadata && su.app_metadata.provider) || "login").slice(0, 30), token = crypto.randomBytes(32).toString("base64url"), h = tokenHash(token).toString("hex");
  let row = await db.getUserByAuth(su.id);
  if (row) { await db.addSession(row.id, h); res.append("Set-Cookie", SESSION_COOKIE(token, req)); return row; }                  // welcome back, on any device
  const current = await userFromCookie(req.headers.cookie);
  if (current && !(await db.getAuthProvider(current.id))) { await db.linkAuth(current.id, su.id, provider); return current; }       // a guest saves their account: number, workspaces and counts stay
  for (let tries = 0; tries < 3; tries++) {
    try { row = await db.createAuthUser(h, await freeName(profileName(su)), su.id, provider); res.append("Set-Cookie", SESSION_COOKIE(token, req)); return row; }
    catch (err) { if (!(err && err.taken)) throw err; }
  }
  throw new Error("Could not find a free name");
}
// Google gives no UUID, but our database column is a UUID: turn "google:<id>" into a stable one (same person -> same value, always).
const uuidFrom = text => { const b = crypto.createHash("sha256").update(text).digest().subarray(0, 16); b[6] = (b[6] & 0x0f) | 0x50; b[8] = (b[8] & 0x3f) | 0x80; const x = b.toString("hex"); return `${x.slice(0, 8)}-${x.slice(8, 12)}-${x.slice(12, 16)}-${x.slice(16, 20)}-${x.slice(20)}`; };
function googleIdentity(idToken) {      // the token comes straight from Google over HTTPS in exchange for our secret, so reading it is enough (OpenID Connect rule)
  const p = String(idToken || "").split("."); if (p.length !== 3) throw new Error("Bad id_token");
  const c = JSON.parse(Buffer.from(p[1], "base64url").toString("utf8"));
  if (c.aud !== process.env.GOOGLE_CLIENT_ID || !/^https:\/\/accounts\.google\.com$|^accounts\.google\.com$/.test(String(c.iss)) || !c.sub || !(Number(c.exp) * 1000 > Date.now())) throw new Error("id_token rejected");
  return { id: uuidFrom("google:" + String(c.sub)), app_metadata: { provider: "google" }, user_metadata: { full_name: c.name || c.given_name || "" } };
}
app.get("/auth/callback", ipLimit("auth-cb", 1, 10), async (req, res) => {
  res.set("Cache-Control", "no-store");
  const c = parseCookies(req.headers.cookie), verifier = c.sp_pkce || "", next = SAFE_NEXT.test("/" + String(c.sp_next || "").replace("_", "/")) ? "/" + String(c.sp_next).replace("_", "/") : "/";
  res.append("Set-Cookie", flowCookie("sp_pkce", "", req, 0)); res.append("Set-Cookie", flowCookie("sp_next", "", req, 0));
  const back = flag => res.redirect(302, (flag === "ok" ? next : "/") + "?login=" + flag);
  const code = String(req.query.code || "");
  if (c.sp_state) {                                                                    // came back from Google directly
    res.append("Set-Cookie", flowCookie("sp_state", "", req, 0));
    const okState = typeof req.query.state === "string" && req.query.state.length === c.sp_state.length && crypto.timingSafeEqual(Buffer.from(req.query.state), Buffer.from(c.sp_state));
    if (!providerReady("google") || !googleDirect() || req.query.error || !okState || !/^[\w./~-]{8,600}$/.test(code) || !/^[A-Za-z0-9_-]{43,128}$/.test(verifier)) return back("failed");
    try {
      const r = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, signal: AbortSignal.timeout(10000),
        body: new URLSearchParams({ code, client_id: process.env.GOOGLE_CLIENT_ID, client_secret: process.env.GOOGLE_CLIENT_SECRET, redirect_uri: siteOrigin(req) + "/auth/callback", grant_type: "authorization_code", code_verifier: verifier }).toString()
      });
      const d = await r.json().catch(() => ({}));
      if (!r.ok || !d.id_token) { console.error("[SyncPit] Google sign-in failed:", r.status, d && (d.error_description || d.error)); return back("failed"); }
      await signInWith(googleIdentity(d.id_token), req, res);
      userCache.clear();
      return back("ok");
    } catch (err) { console.error("[SyncPit] Google sign-in failed (did you run supabase/schema.sql?):", err.message || err); return back("failed"); }
  }
  if (!authReady() || !supaAuthOk() || req.query.error || !/^[\w.-]{8,300}$/.test(code) || !/^[A-Za-z0-9_-]{43,128}$/.test(verifier)) return back("failed");
  try {
    const r = await fetch(process.env.SUPABASE_URL.replace(/\/+$/, "") + "/auth/v1/token?grant_type=pkce", {
      method: "POST", headers: { "Content-Type": "application/json", apikey: authKey() }, signal: AbortSignal.timeout(10000),
      body: JSON.stringify({ auth_code: code, code_verifier: verifier })
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.user || !/^[0-9a-f-]{36}$/i.test(String(d.user.id))) { console.error("[SyncPit] Sign-in code exchange failed:", r.status, d && (d.msg || d.error_description || d.error)); return back("failed"); }
    await signInWith(d.user, req, res);
    userCache.clear();
    back("ok");
  } catch (err) { console.error("[SyncPit] Sign-in failed (did you run supabase/schema.sql?):", err.message || err); back("failed"); }
});
app.post("/api/auth/logout", ipLimit("auth-out", 1, 10), async (req, res) => {
  res.set("Cache-Control", "no-store");
  if (!sameOrigin(req)) return res.status(403).json({ error: "Not allowed." });
  const t = parseCookies(req.headers.cookie).cr_session;
  if (t && /^[A-Za-z0-9_-]{40,60}$/.test(t)) { const h = tokenHash(t).toString("hex"); userCache.delete(h); try { await db.deleteSession(h); } catch {} }
  res.append("Set-Cookie", `cr_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${req.secure ? "; Secure" : ""}`);
  res.json({ ok: true });
});
// ---------- feedback -> Telegram (or Discord) ----------
// The bot token / webhook link are secrets: they live only in the server environment, are never sent to the browser and never logged.
const FEEDBACK_KINDS = { bug: { label: "Bug", icon: "\ud83d\udc1e", color: 0xe5484d }, idea: { label: "Idea", icon: "\ud83d\udca1", color: 0x8b5cf6 }, other: { label: "Other", icon: "\ud83d\udcac", color: 0x3fb68b } };
function feedbackTarget() {
  const tok = String(process.env.TELEGRAM_BOT_TOKEN || "").trim(), chat = String(process.env.TELEGRAM_CHAT_ID || "").trim();
  if (/^\d{6,12}:[\w-]{30,60}$/.test(tok) && /^(-?\d{5,20}|@[A-Za-z][\w]{4,31})$/.test(chat)) return { type: "telegram", tok, chat };
  const hook = String(process.env.FEEDBACK_WEBHOOK_URL || "").trim();
  if (/^https:\/\/(?:discord|discordapp)\.com\/api\/webhooks\/\d{5,25}\/[\w-]{20,120}$/.test(hook)) return { type: "discord", hook };
  return null;
}
async function deliverFeedback(target, kind, who, message) {
  const signal = AbortSignal.timeout(8000);
  if (target.type === "telegram") {
    const r = await fetch("https://api.telegram.org/bot" + target.tok + "/sendMessage", {
      method: "POST", headers: { "Content-Type": "application/json" }, signal,
      body: JSON.stringify({ chat_id: target.chat, disable_web_page_preview: true, text: kind.icon + " " + kind.label + " feedback\nFrom: " + who + "\n\n" + message })   // plain text: no formatting can be injected
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.ok) throw new Error("Telegram answered " + r.status);
    return;
  }
  const r = await fetch(target.hook, {
    method: "POST", headers: { "Content-Type": "application/json" }, signal,
    body: JSON.stringify({ username: "SyncPit Feedback", allowed_mentions: { parse: [] },          // a message can never ping @everyone or roles
      embeds: [{ title: kind.label + " feedback", description: message, color: kind.color, fields: [{ name: "From", value: who.slice(0, 200) }], footer: { text: "SyncPit" }, timestamp: new Date().toISOString() }] })
  });
  if (!r.ok) throw new Error("Discord answered " + r.status);
}
const feedbackSent = new Map();                                    // user id -> times of recent messages
const FEEDBACK_GAP_MS = 20 * 1000, FEEDBACK_PER_HOUR = 5;
const feedbackAll = [], FEEDBACK_GLOBAL_PER_HOUR = 60;           // site-wide cap so a spam wave can never flood the Telegram chat
app.post("/api/feedback", ipLimit("feedback", 10 / 3600, 5), async (req, res) => {
  res.set("Cache-Control", "no-store");
  if (!sameOrigin(req)) return res.status(403).json({ error: "Not allowed." });
  const user = await userFromCookie(req.headers.cookie).catch(() => null);
  if (!user) return res.status(401).json({ error: "Pick your name first, then send your feedback." });
  const target = feedbackTarget();
  if (!target) return res.status(503).json({ error: "Feedback isn't set up on this server yet." });
  const b = req.body || {}, kind = FEEDBACK_KINDS[b.kind];
  if (!kind || typeof b.message !== "string") return res.status(400).json({ error: "Choose a type and write a message." });
  const message = b.message.replace(/\r\n?/g, "\n").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").replace(/\n{3,}/g, "\n\n").trim();
  if (message.length < 5) return res.status(400).json({ error: "Please write a little more (at least 5 characters)." });
  if (message.length > 1000) return res.status(400).json({ error: "That's too long. Please keep it under 1000 characters." });
  const nowG = Date.now(); while (feedbackAll.length && nowG - feedbackAll[0] > 3600 * 1000) feedbackAll.shift();
  if (feedbackAll.length >= FEEDBACK_GLOBAL_PER_HOUR) return res.status(429).json({ error: "We're receiving a lot of feedback right now. Please try again a little later." });
  const now = Date.now(), recent = (feedbackSent.get(user.id) || []).filter(t => now - t < 3600 * 1000);
  if (recent.length && now - recent[recent.length - 1] < FEEDBACK_GAP_MS) return res.status(429).json({ error: "Please wait a few seconds before sending another." });
  if (recent.length >= FEEDBACK_PER_HOUR) return res.status(429).json({ error: "You've sent a lot of feedback this hour. Thank you! Please try again later." });
  try {
    const who = user.name + " \u00b7 #" + user.id + (user.dev ? " \u00b7 developer" : user.role ? " \u00b7 " + user.role : "");
    await deliverFeedback(target, kind, who.slice(0, 200), message);
    recent.push(now); feedbackSent.set(user.id, recent); feedbackAll.push(now);
    if (feedbackSent.size > 2000) feedbackSent.delete(feedbackSent.keys().next().value);
    res.json({ ok: true });
  } catch (err) { console.error("[SyncPit] Feedback failed:", err && err.name === "TimeoutError" ? "timed out" : (err && err.message) || "error"); res.status(502).json({ error: "Couldn't send your feedback right now. Please try again in a moment." }); }
});

// ---------- phonk music search (Audius) ----------
// Public for everyone. The browser only talks to this server; the optional Audius token stays here (AUDIUS_BEARER_TOKEN), never in public/.
const AUDIUS_BASE = "https://api.audius.co/v1", AUDIUS_APP = "SyncPit";
const audiusHeaders = extra => ({ ...(process.env.AUDIUS_BEARER_TOKEN ? { Authorization: "Bearer " + process.env.AUDIUS_BEARER_TOKEN } : {}), ...(extra || {}) });
const searchCache = new Map();                                   // query -> { at, tracks }; keeps repeat searches fast and cheap
const SEARCH_TTL = 5 * 60 * 1000;
app.get("/api/music/search", ipLimit("music-search", 2, 20), async (req, res) => {
  res.set("Cache-Control", "no-store");
  const q = String(req.query.q || "").replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
  if (!q) return res.json({ tracks: [] });
  const key = q.toLowerCase(), hit = searchCache.get(key);
  if (hit && Date.now() - hit.at < SEARCH_TTL) return res.json({ tracks: hit.tracks });
  try {
    const r = await fetch(AUDIUS_BASE + "/tracks/search?limit=20&app_name=" + AUDIUS_APP + "&query=" + encodeURIComponent(q), { headers: audiusHeaders({ Accept: "application/json" }), signal: AbortSignal.timeout(8000) });
    if (!r.ok) throw new Error("Audius search " + r.status);
    const d = await r.json();
    const tracks = (Array.isArray(d.data) ? d.data : [])
      .filter(t => t && /^[A-Za-z0-9]{3,20}$/.test(String(t.id)) && t.is_streamable !== false && !t.is_stream_gated && !t.is_delete && !t.is_unlisted)
      .slice(0, 20).map(t => ({ id: String(t.id), title: String(t.title || "Untitled").slice(0, 120), artist: String((t.user && t.user.name) || "Unknown artist").slice(0, 80), duration: Math.max(0, Number(t.duration) || 0) }));
    if (searchCache.size > 200) searchCache.delete(searchCache.keys().next().value);
    searchCache.set(key, { at: Date.now(), tracks });
    res.json({ tracks });
  } catch (err) { console.error("[SyncPit] Music search failed:", err.message || err); res.status(502).json({ error: "Music search isn't available right now. Try again in a moment." }); }
});
// Streams the audio through this server (supports seeking), so the browser never needs the token and the page's security policy stays strict.
app.get("/api/music/stream/:id", ipLimit("music-stream", 1, 40), async (req, res) => {
  const id = String(req.params.id || "");
  if (!/^[A-Za-z0-9]{3,20}$/.test(id)) return res.status(400).end();
  const ctl = new AbortController(); res.on("close", () => ctl.abort());
  try {
    const up = await fetch(AUDIUS_BASE + "/tracks/" + id + "/stream?app_name=" + AUDIUS_APP, { headers: audiusHeaders(req.headers.range ? { Range: String(req.headers.range).slice(0, 60) } : {}), signal: ctl.signal, redirect: "follow" });
    const type = String(up.headers.get("content-type") || "");
    if (!(up.status === 200 || up.status === 206) || !/^(audio\/|application\/octet-stream)/i.test(type) || !up.body) return res.status(502).end();
    res.status(up.status);
    res.set({ "Content-Type": /^audio\//i.test(type) ? type : "audio/mpeg", "Accept-Ranges": up.headers.get("accept-ranges") || "bytes", "Cache-Control": "private, max-age=3600", "X-Content-Type-Options": "nosniff" });
    for (const h of ["content-length", "content-range"]) if (up.headers.get(h)) res.set(h, up.headers.get(h));
    require("stream").Readable.fromWeb(up.body).on("error", () => res.destroy()).pipe(res);
  } catch (err) { if (!res.headersSent) res.status(502).end(); else res.destroy(); }
});

// ---------- roles: only the developer can give or remove them ----------
const notFound = res => res.status(404).type("text/plain").send("Not found");
async function developerOnly(req, res) {
  const u = await userFromCookie(req.headers.cookie).catch(() => null);
  if (!u || !(u.dev || u.role === "monster")) { notFound(res); return null; }
  return u;
}
// ---------- settings: limits, and changing your name (once every 30 days) ----------
const NAME_CHANGE_DAYS = 30, NAME_CHANGE_MS = NAME_CHANGE_DAYS * 24 * 3600 * 1000;
const LIMITS = () => ({ nameMax: 24, nameDays: NAME_CHANGE_DAYS, maxCode: MAX_CODE_LENGTH, maxPeople: MAX_PARTICIPANTS, savedShown: 50, runFastSeconds: 5, runSlowSeconds: 30, outputChars: 20000, inputLines: 200 });   // run limits mirror runner.html / app.js
app.get("/api/me/settings", ipLimit("me-settings", 1, 20), async (req, res) => {
  res.set("Cache-Control", "no-store");
  const u = await userFromCookie(req.headers.cookie).catch(() => null);
  if (!u) return res.status(401).json({ error: "No user." });
  let nameChange = { canChange: false, lastAt: null, nextAt: null, unavailable: true };
  try {
    const info = await db.getNameInfo(u.id), last = info && info.at ? info.at : null, next = last ? last + NAME_CHANGE_MS : null;
    nameChange = { canChange: !next || next <= Date.now(), lastAt: last, nextAt: next };
  } catch (err) { console.error("[SyncPit] Name changes need the new column. Fix: Supabase > SQL Editor > run supabase/schema.sql again. (" + (err.message || err) + ")"); }
  res.json({ user: { id: u.id, name: u.name, dev: u.dev, role: u.role, provider: await db.getAuthProvider(u.id).catch(() => null) }, nameChange, limits: LIMITS() });
});
app.post("/api/me/name", ipLimit("name-change", 1, 5), async (req, res) => {
  res.set("Cache-Control", "no-store");
  if (!db) return res.status(503).json({ error: "Database is not configured on the server." });
  if (!sameOrigin(req)) return res.status(403).json({ error: "Not allowed." });
  const u = await userFromCookie(req.headers.cookie).catch(() => null);
  if (!u) return res.status(401).json({ error: "Pick a name first." });
  const name = cleanName(req.body && req.body.name);
  if (!name) return res.status(400).json({ error: "Please enter a name." });
  if (name === u.name) return res.status(400).json({ error: "That is already your name." });
  try {
    const now = Date.now(), info = await db.getNameInfo(u.id);
    if (info && info.at && now - info.at < NAME_CHANGE_MS) return res.status(429).json({ error: "You changed your name recently. You can change it again later.", nextAt: info.at + NAME_CHANGE_MS });
    if (name.toLowerCase() !== u.name.toLowerCase() && await db.nameTaken(name)) return res.status(409).json({ error: "That name is already taken. Please choose another.", taken: true });
    const ok = await db.renameUser(u.id, name, new Date(now).toISOString(), new Date(now - NAME_CHANGE_MS).toISOString());
    if (!ok) { const again = await db.getNameInfo(u.id); return res.status(429).json({ error: "You changed your name recently. You can change it again later.", nextAt: again && again.at ? again.at + NAME_CHANGE_MS : now + NAME_CHANGE_MS }); }
    applyNameLive(u.id, name);
    res.json({ user: { id: u.id, name, dev: u.dev, role: u.role }, nextAt: now + NAME_CHANGE_MS });
  } catch (err) {
    if (err && err.taken) return res.status(409).json({ error: "That name is already taken. Please choose another.", taken: true });
    console.error("[SyncPit] Name change failed (did you run supabase/schema.sql?):", err.message || err); res.status(500).json({ error: "Could not change your name. Please try again." });
  }
});
function applyNameLive(id, name) {
  let role = null; for (const u of userCache.values()) if (u.id === id) { u.name = name; role = u.role; }
  const touched = new Set();
  for (const s of io.sockets.sockets.values()) {
    if (s.data.uid !== id && !(s.data.author && s.data.author.uid === id)) continue;
    if (s.data.author) s.data.author.name = name;
    s.emit("me-updated", { user: { id, name, dev: isDevId(id), role: roleOf(id, role) } });
    if (s.data.roomId) touched.add(s.data.roomId);
  }
  for (const rid of touched) { const room = rooms.get(rid); if (room) io.to(rid).emit("presence", { peers: peersOf(room) }); }       // everyone in the room sees the new name at once
}
function applyRoleLive(id, role) {
  for (const u of userCache.values()) if (u.id === id) u.role = role;                 // later requests see the new role
  const touched = new Set();
  for (const s of io.sockets.sockets.values()) {
    if (s.data.uid !== id && !(s.data.author && s.data.author.uid === id)) continue;
    if (s.data.author) s.data.author.role = role;
    s.emit("me-updated", { user: { id, name: s.data.author ? s.data.author.name : undefined, dev: false, role } });
    if (s.data.roomId) touched.add(s.data.roomId);
  }
  for (const rid of touched) { const room = rooms.get(rid); if (room) io.to(rid).emit("presence", { peers: peersOf(room) }); }
}
app.get("/api/roles", ipLimit("roles-find", 2, 20), async (req, res) => {
  res.set("Cache-Control", "no-store");
  if (!(await developerOnly(req, res))) return;
  const q = cleanName(req.query.q);
  if (!q) return res.json({ users: [] });
  try {
    const found = await db.searchUsers(q), st = await statsFor(found.map(u => Number(u.id)));
    res.json({ users: found.map(u => ({ id: Number(u.id), name: u.name, dev: isDevId(u.id), role: roleOf(u.id, u.role), stats: st[Number(u.id)] })) });
  }
  catch (err) { console.error("[SyncPit] Role search failed:", err.message || err); res.status(500).json({ error: "Could not search users." }); }
});
app.get("/api/roles/top", ipLimit("roles-top", 1, 10), async (req, res) => {       // developer only: who has created the most workspaces
  res.set("Cache-Control", "no-store");
  if (!(await developerOnly(req, res))) return;
  try {
    const rows = await db.topCreators(10).catch(err => { statsFail(err); return []; }), st = await statsFor(rows.map(u => Number(u.id)));
    res.json({ users: rows.map(u => ({ id: Number(u.id), name: u.name, dev: isDevId(u.id), role: roleOf(u.id, u.role), stats: st[Number(u.id)] })) });
  } catch (err) { console.error("[SyncPit] Top creators failed:", err.message || err); res.status(500).json({ error: "Could not load the list." }); }
});
app.get("/api/me/stats", ipLimit("me-stats", 1, 20), async (req, res) => {         // everyone sees their own counts
  res.set("Cache-Control", "no-store");
  const u = await userFromCookie(req.headers.cookie).catch(() => null);
  if (!u) return res.status(401).json({ error: "No user." });
  res.json((await statsFor([u.id]))[u.id]);
});
app.post("/api/roles", ipLimit("roles", 1, 40), async (req, res) => {
  res.set("Cache-Control", "no-store");
  if (!(await developerOnly(req, res))) return;
  if (!sameOrigin(req)) return res.status(403).json({ error: "Not allowed." });
  const { userNumber, role } = req.body || {};
  if (!Number.isInteger(userNumber) || userNumber < 1) return res.status(400).json({ error: "Enter a valid user number." });
  if (role !== null && !ROLES.includes(role)) return res.status(400).json({ error: "Role must be admin, moderator, bauna, monster, or none." });
  if (isDevId(userNumber)) return res.status(403).json({ error: "The developer account can't be changed." });
  try {
    const target = await db.getUserById(userNumber);
    if (!target) return res.status(404).json({ error: "No user has that number." });
    const actor = await userFromCookie(req.headers.cookie).catch(() => null);
    if ((role === "monster" || target.role === "monster") && !(actor && actor.dev)) return res.status(403).json({ error: "Only the developer can give or remove MONSTER." });
    await db.setUserRole(userNumber, role);
    applyRoleLive(userNumber, role);
    res.json({ user: { id: userNumber, name: target.name, dev: false, role } });
  } catch (err) { console.error("[SyncPit] Role change failed:", err.message || err); res.status(500).json({ error: "Could not change the role." }); }
});
app.get("/room/:id", (_req, res) => { res.set("Cache-Control", "no-store"); res.sendFile(path.join(__dirname, "public", "index.html")); });
app.use((_req, res) => res.status(404).type("text/plain").send("Not found"));
app.use((err, _req, res, _next) => { console.error("[SyncPit] Request error:", err.message || err); res.status(err.status || 500).json({ error: "Something went wrong." }); });

// ---------- realtime ----------
const extraOrigins = (process.env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
const io = new Server(server, {
  maxHttpBufferSize: 256 * 1024,
  allowRequest: (req, cb) => {
    const o = req.headers.origin;
    if (!o) return cb(null, true); // not a browser
    try { cb(null, extraOrigins.includes(o) || new URL(o).host === req.headers.host); } catch { cb(null, false); }
  }
});

io.use(async (socket, next) => {                       // while maintenance is on, only the developer can connect
  if (maint.phase !== "on") return next();
  try { if (isStaff(await userFromCookie(socket.request.headers.cookie))) return next(); } catch {}
  next(new Error("maintenance"));
});

const socketsByIp = new Map(), MAX_SOCKETS_PER_IP = 40;
// Wrong owner keys: after too many misses an IP's owner keys are ignored for a while (the person can still view and edit as a visitor).
const ownerMiss = new Map(), OWNER_MISS_MAX = 15, OWNER_MISS_WINDOW_MS = 15 * 60 * 1000;
const ownerBlocked = ip => { const e = ownerMiss.get(ip); if (!e) return false; if (Date.now() - e.t > OWNER_MISS_WINDOW_MS) { ownerMiss.delete(ip); return false; } return e.n >= OWNER_MISS_MAX; };
const ownerMissed = ip => { const e = ownerMiss.get(ip); if (!e || Date.now() - e.t > OWNER_MISS_WINDOW_MS) ownerMiss.set(ip, { n: 1, t: Date.now() }); else e.n++; if (ownerMiss.size > 5000) ownerMiss.clear(); };
setInterval(() => { const now = Date.now(); for (const [k, e] of ownerMiss) if (now - e.t > OWNER_MISS_WINDOW_MS) ownerMiss.delete(k); }, 10 * 60 * 1000).unref();
io.on("connection", socket => {
  const behindProxy = Boolean(process.env.TRUST_PROXY || process.env.RENDER);
  const fwd = behindProxy ? String(socket.handshake.headers["x-forwarded-for"] || "").split(",")[0].trim() : "";
  const ip = fwd || socket.handshake.address || "?";
  if ((socketsByIp.get(ip) || 0) >= MAX_SOCKETS_PER_IP) { socket.disconnect(true); return; }
  socketsByIp.set(ip, (socketsByIp.get(ip) || 0) + 1);
  socket.on("disconnect", () => { const n = (socketsByIp.get(ip) || 1) - 1; if (n <= 0) socketsByIp.delete(ip); else socketsByIp.set(ip, n); });
  userFromCookie(socket.request.headers.cookie).then(u => { if (u) { socket.data.uid = u.id; socket.data.isDev = isDevUser(u); } }).catch(() => {});
  if (maint.phase !== "off") socket.emit("maintenance", maintPublic());
  const limits = { op: mkBucket(60, 120), cursor: mkBucket(40, 60), misc: mkBucket(8, 20) };
  let strikes = 0;
  const guard = (kind, fn) => async (...args) => {
    if (args[0] === null) args[0] = undefined;
    if (!take(limits[kind])) { if (++strikes > 300) socket.disconnect(true); return; }
    try { await fn(...args); } catch (err) { console.error("[SyncPit] Handler error:", err.message || err); }
  };
  const inRoom = id => {
    const room = typeof id === "string" ? rooms.get(id) : null;
    return room && socket.data.roomId === id ? room : null;
  };

  socket.on("join-room", guard("misc", async ({ id, ownerToken, clientId, name } = {}) => {
    if (typeof id !== "string") return;
    const user = await userFromCookie(socket.request.headers.cookie).catch(() => null);
    if (!user) { socket.emit("need-user"); return; }
    let room;
    try { room = await loadRoom(id); }
    catch (err) { console.error("[SyncPit] Load failed:", err.message || err); socket.emit("room-error", "Could not load this workspace right now. Please retry in a moment."); return; }
    if (!room) { socket.emit("room-error", "This workspace does not exist. Check the link or create a new one."); return; }
    let owner = false;
    if (typeof ownerToken === "string" && ownerToken) {
      if (!ownerBlocked(ip)) { owner = isOwnerToken(room, ownerToken); if (!owner) ownerMissed(ip); }
    }
    if (room.sockets.size >= MAX_PARTICIPANTS && !room.sockets.has(socket.id) && !owner) { socket.emit("room-error", "This workspace is full right now."); return; }
    if (socket.data.roomId && socket.data.roomId !== id) {
      const old = rooms.get(socket.data.roomId);
      if (old) { old.sockets.delete(socket.id); io.to(socket.data.roomId).emit("presence", { peers: peersOf(old) }); maybeEvict(socket.data.roomId, old); }
      socket.leave(socket.data.roomId);
    }
    clearTimeout(room.evictTimer);
    socket.data.roomId = id; socket.data.isOwner = owner; socket.data.cursor = null;
    socket.data.author = { aid: "u" + user.id, uid: user.id, role: user.role, name: user.name, color: pickColor(room, "u" + user.id) };
    room.sockets.add(socket.id); socket.join(id);
    socket.emit("room-state", publicState(id, room, socket));
    socket.to(id).emit("presence", { peers: peersOf(room) });
  }));

  socket.on("op", guard("op", ({ id, rev, op } = {}) => {
    const room = inRoom(id);
    if (!room) return;
    const resync = () => socket.emit("resync", publicState(id, room, socket));
    if (room.locked && !socket.data.isOwner) { socket.emit("permission-error", "This workspace is locked by its owner. You can still view and copy the code."); return resync(); }
    if (!Number.isInteger(rev) || rev < 0 || rev > room.rev || room.rev - rev > room.log.length || rev < room.logStart) return resync();
    const lenAtRev = rev === room.rev ? room.code.length : room.lens[rev - room.logStart];
    if (!OT.validate(op, lenAtRev, MAX_CODE_LENGTH)) return resync();
    let o = op;
    for (let k = rev; k < room.rev; k++) o = OT.transform(o, room.log[k - room.logStart], "right");
    if (!OT.validate(o, room.code.length, MAX_CODE_LENGTH)) return resync();
    if (OT.apply(room.code, o).length > MAX_CODE_LENGTH) { socket.emit("permission-error", "Maximum code length is 80,000 characters."); return resync(); }
    if (!o.length) { socket.emit("ack", { rev: room.rev }); return; }
    const newRev = commitOp(id, room, socket.data.author, o, socket);
    socket.emit("ack", { rev: newRev });
  }));

  socket.on("cursor", guard("cursor", ({ id, a, b } = {}) => {
    const room = inRoom(id);
    if (!room || !Number.isInteger(a) || !Number.isInteger(b) || a < 0 || b < 0 || a > room.code.length || b > room.code.length) return;
    socket.data.cursor = { a, b };
    socket.to(id).volatile.emit("cursor", { pid: socket.id, a, b });
  }));

  socket.on("language", guard("misc", ({ id, language } = {}) => {
    const room = inRoom(id);
    if (!room || typeof language !== "string") return;
    if (room.locked && !socket.data.isOwner) return;
    const lang = language.slice(0, 60);
    if (lang === room.language) return;
    const e = systemEntry(room, socket.data.author, "language", room.language, lang);
    room.language = lang; scheduleSave(id, room, 0);
    io.to(id).emit("language", { language: lang }); broadcastHistory(id, e);
  }));

  socket.on("set-lock", guard("misc", ({ id, ownerToken, locked } = {}) => {
    const room = inRoom(id);
    if (!room || ownerBlocked(ip) || !isOwnerToken(room, ownerToken)) { if (room) ownerMissed(ip); socket.emit("permission-error", "Only the workspace owner can change the editing lock."); return; }
    room.locked = Boolean(locked);
    scheduleSave(id, room, 0);
    const e = systemEntry(room, socket.data.author, room.locked ? "lock" : "unlock");
    for (const sid of room.sockets) {
      const peer = io.sockets.sockets.get(sid);
      if (peer) peer.emit("lock-state", { locked: room.locked, isOwner: Boolean(peer.data.isOwner) });
    }
    broadcastHistory(id, e);
  }));

  socket.on("maint-set", guard("misc", async ({ action, seconds } = {}) => {
    const u = await userFromCookie(socket.request.headers.cookie).catch(() => null);
    if (!isStaff(u)) { socket.emit("permission-error", "Only the developer can change maintenance mode."); return; }
    const who = u.name + " (developer)";
    if (action === "start" && maint.phase === "off") setMaintenance("start", seconds, who);
    else if (action === "off" && maint.phase !== "off") setMaintenance("off");
  }));

  // Owner key reset: proves the current key, then swaps in a brand new one. The old key (and any other device using it) stops being owner at once.
  socket.on("rotate-owner-key", guard("misc", ({ id, ownerToken } = {}) => {
    const room = inRoom(id);
    if (!room || ownerBlocked(ip) || !isOwnerToken(room, ownerToken)) { if (room) ownerMissed(ip); socket.emit("permission-error", "Only the workspace owner can reset the owner key."); return; }
    const fresh = crypto.randomBytes(32).toString("base64url");
    room.ownerTokenHash = tokenHash(fresh);
    scheduleSave(id, room, 0);
    for (const sid of room.sockets) {
      if (sid === socket.id) continue;
      const peer = io.sockets.sockets.get(sid);
      if (peer && peer.data.isOwner) { peer.data.isOwner = false; peer.emit("lock-state", { locked: room.locked, isOwner: false }); }
    }
    socket.emit("owner-key-rotated", { id, ownerToken: fresh });
  }));

  socket.on("delete-room", guard("misc", async ({ id, ownerToken } = {}) => {
    const room = inRoom(id);
    if (!room || ownerBlocked(ip) || !isOwnerToken(room, ownerToken)) { if (room) ownerMissed(ip); socket.emit("permission-error", "Only the workspace owner can delete the workspace."); return; }
    room.deleted = true; clearTimeout(room.saveTimer); clearTimeout(room.evictTimer); clearTimeout(room.histTimer);
    try { await db.deleteRoom(id); }
    catch (err) { room.deleted = false; console.error("[SyncPit] Delete failed:", err.message || err); socket.emit("permission-error", "Could not delete the workspace. Please try again."); return; }
    setTimeout(() => db.deleteRoom(id).catch(() => {}), 3000).unref();   // catches a save that was already in flight
    rooms.delete(id);
    io.to(id).emit("room-deleted");
    for (const sid of room.sockets) { const s = io.sockets.sockets.get(sid); if (s) { s.leave(id); s.data.roomId = null; } }
  }));

  socket.on("revert", guard("misc", ({ id, entryId } = {}) => {
    const room = inRoom(id);
    if (!room) return;
    if (room.locked && !socket.data.isOwner) { socket.emit("permission-error", "This workspace is locked by its owner."); return; }
    const entry = room.history.find(h => h.id === entryId);
    if (!entry || entry.kind !== "edit" || entry.reverted) { socket.emit("history-error", "That change can't be reverted."); return; }
    if (entry.trunc) { socket.emit("history-error", "This change is too large to revert automatically."); return; }
    const first = room.code.indexOf(entry.after);
    if (first === -1 || first !== room.code.lastIndexOf(entry.after) || !entry.after) {
      socket.emit("history-error", "Those lines have changed since this edit, so it can't be reverted automatically."); return;
    }
    const next = room.code.slice(0, first) + entry.before + room.code.slice(first + entry.after.length);
    const op = OT.fromDiff(room.code, next);
    const author = socket.data.author;
    entry.reverted = true; room.dirtyEntries.set(entry.id, entry);
    closeOpen(room); room.entrySeq++;
    commitOp(id, room, author, op, null);   // everyone, including the sender, receives it as a normal change
    const rev = systemEntry(room, author, "revert", entry.after, entry.before);
    rev.start = lineIndex(next, first) + 1; rev.end = rev.start + entry.before.split("\n").length - 1;
    broadcastHistory(id, entry); broadcastHistory(id, rev);
  }));

  socket.on("history-page", guard("misc", async ({ id, before } = {}, cb) => {
    const room = inRoom(id);
    if (!room || typeof cb !== "function" || !Number.isFinite(before)) return;
    const memOld = room.history.filter(h => h.ts < before).sort((a, b) => b.ts - a.ts).slice(0, 50);
    if (memOld.length >= 50 || !db) return cb({ entries: memOld.map(entryOut) });
    const rows = await db.listHistory(id, before, 50);
    cb({ entries: rows.map(rowToEntry).map(entryOut) });
  }));

  socket.on("share-run", guard("misc", ({ id, lang, ok, ms, lines } = {}) => {
    const room = inRoom(id);
    if (!room || !Array.isArray(lines) || (room.locked && !socket.data.isOwner)) return;
    let total = 0; const out = [];
    for (const l of lines.slice(0, 200)) {
      if (!l || typeof l.text !== "string") continue;
      const text = l.text.slice(0, 500); total += text.length;
      if (total > 12000) break;
      out.push({ t: ["log", "error", "info"].includes(l.t) ? l.t : "log", text });
    }
    socket.to(id).emit("peer-run", { name: socket.data.author.name, color: socket.data.author.color, lang: String(lang || "").slice(0, 40), ok: Boolean(ok), ms: Number.isFinite(ms) ? Math.round(ms) : 0, lines: out });
  }));

  socket.on("disconnect", () => {
    const id = socket.data.roomId;
    const room = id && rooms.get(id);
    if (!room) return;
    room.sockets.delete(socket.id);
    io.to(id).emit("presence", { peers: peersOf(room) });
    if (room.sockets.size === 0) flushRoom(id, room).then(() => maybeEvict(id, room));
  });
});

let shuttingDown = false;
async function shutdown() { if (shuttingDown) return; shuttingDown = true; await flushAll(); process.exit(0); }
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

if (require.main === module) server.listen(PORT, () => console.log(`SyncPit running at http://localhost:${PORT}`));
module.exports = { server, io, seal, open, db };
