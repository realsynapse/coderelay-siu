process.env.DEV_MEMORY_DB = "1";
const assert = require("assert");
const WebSocket = require("ws");
const { server } = require("../server.js");

function sioClient(port, cookie) {
  const ws = new WebSocket(`ws://127.0.0.1:${port}/socket.io/?EIO=4&transport=websocket`, { headers: cookie ? { cookie } : {} });
  const handlers = {}, log = []; let resolveReady;
  const api = {
    log, ready: new Promise(res => { resolveReady = res; }),
    emit(ev, payload) { ws.send("42" + JSON.stringify([ev, payload])); },
    next(ev, ms = 3000) { return new Promise((res, rej) => { const t = setTimeout(() => rej(new Error("timeout waiting for " + ev)), ms); (handlers[ev] = handlers[ev] || []).push(function once(d) { clearTimeout(t); handlers[ev] = handlers[ev].filter(x => x !== once); res(d); }); }); },
    count(ev) { return log.filter(x => x === ev).length; },
    close() { ws.close(); }
  };
  ws.on("message", raw => {
    const m = raw.toString();
    if (m === "2") return ws.send("3");
    if (m[0] === "0") return ws.send("40");
    if (m.startsWith("40")) return resolveReady();
    const mm = m.match(/^42(\d*)(\[.*)$/); if (!mm) return;
    const arr = JSON.parse(mm[2]); log.push(arr[0]);
    (handlers[arr[0]] || []).slice().forEach(fn => fn(arr[1]));
  });
  return api;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(0, r));
  const port = server.address().port, base = `http://127.0.0.1:${port}`;
  const newUser = async name => { const r = await fetch(base + "/api/me", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name }) }); return { body: await r.json(), cookie: (r.headers.get("set-cookie") || "").split(";")[0] }; };
  const newRoom = async () => (await (await fetch(base + "/api/rooms", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ code: "x", language: "Plain text" }) })).json()).id;
  const join = async (user, id) => { const c = sioClient(port, user.cookie); await c.ready; const st = c.next("room-state"), h = c.next("chat-history"); c.emit("join-room", { id }); return { c, state: await st, history: await h }; };
  const [ua, ub, uc, ud] = [await newUser("Aarav"), await newUser("Mira"), await newUser("Kabir"), await newUser("Dev")];
  const room1 = await newRoom(), room2 = await newRoom();

  // 1. members of a workspace get each other's messages; text is plain, trimmed and capped
  const A = await join(ua, room1), B = await join(ub, room1), C = await join(uc, room2);
  assert.deepStrictEqual(A.history.messages, [], "a new workspace starts with no chat");
  const gotB = B.c.next("chat-msg"), gotA = A.c.next("chat-msg");
  A.c.emit("chat", { id: room1, text: "  hello   <b>team</b>\u0000 " });
  const mB = await gotB, mA = await gotA;
  assert.strictEqual(mB.text, "hello <b>team</b>", "control chars removed and spaces collapsed; HTML is just text");
  assert.strictEqual(mB.name, "Aarav"); assert.strictEqual(mB.aid, A.state.you.aid); assert.deepStrictEqual(mA, mB);
  A.c.emit("chat", { id: room1, text: "z".repeat(900) });
  assert.strictEqual((await B.c.next("chat-msg")).text.length, 500, "messages are capped at 500 characters");
  A.c.emit("chat", { id: room1, text: "   " }); A.c.emit("chat", { id: room1, text: 42 }); A.c.emit("chat", { id: room1 });
  await sleep(250);
  assert.strictEqual(B.c.count("chat-msg"), 2, "empty and non-text messages are ignored");
  console.log("ok  chat: members of the workspace receive messages; text is sanitised, capped at 500, empty ignored");

  // 2. other workspaces and non-members never see it
  assert.strictEqual(C.c.count("chat-msg"), 0, "someone in another workspace receives nothing");
  C.c.emit("chat", { id: room1, text: "sneaky" });                 // C is not in room1
  await sleep(250);
  assert.strictEqual(A.c.count("chat-msg"), 2); assert.strictEqual(B.c.count("chat-msg"), 2, "a non-member cannot post into another workspace");
  const outsider = sioClient(port); await outsider.ready; outsider.emit("chat", { id: room1, text: "no session" }); await sleep(200);
  assert.strictEqual(A.c.count("chat-msg"), 2, "a socket with no session cannot post");
  C.c.emit("chat", { id: room2, text: "own room only" });
  assert.strictEqual((await C.c.next("chat-msg")).text, "own room only");
  await sleep(200); assert.strictEqual(A.c.count("chat-msg"), 2, "each workspace has its own chat");
  console.log("ok  chat: separate per workspace; non-members and sessionless sockets cannot read or post");

  // 3. late joiner sees the chat so far
  const D = await join(ud, room1);
  assert.deepStrictEqual(D.history.messages.map(m => m.text.length), [16, 500].map((n, i) => i ? 500 : "hello <b>team</b>".length), "newcomer receives the messages sent so far");
  console.log("ok  chat: someone who joins later sees the conversation so far");

  // 4. chat disappears only when everybody has left
  A.c.close(); B.c.close(); await sleep(300);
  const D2 = D.c.next("chat-msg"); D.c.emit("chat", { id: room1, text: "still here" }); await D2;
  D.c.close(); await sleep(400);                                  // last one gone (disconnect)
  const E = await join(ua, room1);
  assert.deepStrictEqual(E.history.messages, [], "chat is wiped once everyone has left, even before the workspace is evicted");
  console.log("ok  chat: kept while anyone is still in the workspace, wiped as soon as the last person leaves");

  // 5. leaving through 'leave-room' (New workspace button) counts as leaving
  E.c.emit("chat", { id: room1, text: "bye" }); await E.c.next("chat-msg");
  E.c.emit("leave-room", { id: room1 }); await sleep(250);
  const stray = E.c.count("chat-msg");
  E.c.emit("chat", { id: room1, text: "after leaving" }); await sleep(200);
  assert.strictEqual(E.c.count("chat-msg"), stray, "after leave-room you can no longer post or receive");
  const F = await join(ub, room1);
  assert.deepStrictEqual(F.history.messages, [], "last person pressed 'new workspace': chat is wiped");
  console.log("ok  chat: leave-room (New workspace) also counts as leaving, and wipes an empty chat");

  // 6. rate limit
  F.c.emit("chat", { id: room1, text: "first" }); await F.c.next("chat-msg");
  for (let i = 0; i < 30; i++) F.c.emit("chat", { id: room1, text: "spam " + i });
  await sleep(500);
  assert(F.c.count("chat-msg") < 12, "flooding is rate limited (got " + F.c.count("chat-msg") + ")");
  console.log("ok  chat: flooding is rate limited");

  [E.c, F.c, C.c, outsider].forEach(c => c.close()); server.close(); setTimeout(() => process.exit(0), 100);
})().catch(e => { console.error("FAIL", e); process.exit(1); });
