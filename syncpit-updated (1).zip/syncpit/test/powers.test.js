// Rank powers, looks (palette + animation), custom powers, staff rules and room powers. Run: node test/powers.test.js
process.env.DEV_MEMORY = "1"; process.env.DEV_MEMORY_DB = "1";
const assert = require("assert");
const WebSocket = require("ws");
const OT = require("../public/ot.js");
const { server } = require("../server.js");

function sioClient(port, cookie) {
  const ws = new WebSocket(`ws://127.0.0.1:${port}/socket.io/?EIO=4&transport=websocket`, { headers: cookie ? { cookie } : {} });
  const handlers = {}, log = []; let ok, bad; const ready = new Promise((a, b) => { ok = a; bad = b; });
  const api = {
    log, ready,
    emit(ev, payload) { ws.send("42" + JSON.stringify([ev, payload])); },
    next(ev, ms = 3000) { return new Promise((res, rej) => { const t = setTimeout(() => rej(new Error("timeout waiting for " + ev)), ms); (handlers[ev] = handlers[ev] || []).push(function once(d) { clearTimeout(t); handlers[ev] = handlers[ev].filter(x => x !== once); res(d); }); }); },
    count(ev) { return log.filter(x => x === ev).length; },
    close() { ws.close(); }
  };
  ws.on("message", raw => {
    const m = raw.toString();
    if (m === "2") return ws.send("3");
    if (m[0] === "0") return ws.send("40");
    if (m.startsWith("40")) return ok();
    if (m.startsWith("44")) return bad(new Error("refused: " + m));
    const mm = m.match(/^42(\d*)(\[.*)$/); if (!mm) return;
    const arr = JSON.parse(mm[2]); log.push(arr[0]);
    (handlers[arr[0]] || []).slice().forEach(fn => fn(arr[1]));
  });
  ws.on("error", () => bad(new Error("socket error")));
  return api;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(0, r));
  const port = server.address().port, base = `http://127.0.0.1:${port}`;
  const J = { "content-type": "application/json" };
  const newUser = async name => { const r = await fetch(base + "/api/me", { method: "POST", headers: J, body: JSON.stringify({ name }) }); return { body: await r.json(), cookie: (r.headers.get("set-cookie") || "").split(";")[0] }; };
  const call = (cookie, url, body, extra = {}) => fetch(base + url, { method: "POST", headers: { ...J, ...(cookie ? { cookie } : {}), ...extra }, body: JSON.stringify(body) });
  const get = (cookie, url) => fetch(base + url, { headers: cookie ? { cookie } : {} });
  const mkRoom = async cookie => (await (await call(cookie, "/api/rooms", { code: "start", language: "Plain text" })).json());
  const join = async (user, id, ownerToken) => { const c = sioClient(port, user.cookie); await c.ready; const st = c.next("room-state"); c.emit("join-room", { id, ownerToken }); return { c, state: await st }; };
  const ranks = async () => (await (await get(null, "/api/ranks")).json());
  const meOf = async u => (await (await get(u.cookie, "/api/me")).json()).user;

  // ids: dev #1, then #2.. in order of creation. #6 is a second developer account, so it is skipped for plain users.
  const dev = await newUser("Boss"), A = await newUser("Aria"), B = await newUser("Bo"), C = await newUser("Cy"), D = await newUser("Dee"), dev2 = await newUser("Dev2"), E = await newUser("Eli");
  assert.strictEqual(dev.body.user.dev, true); assert.strictEqual(dev2.body.user.id, 6);
  const ids = { A: A.body.user.id, B: B.body.user.id, C: C.body.user.id, D: D.body.user.id, E: E.body.user.id };
  const giveRank = (who, role) => call(dev.cookie, "/api/roles", { userNumber: ids[who], role });

  // 1. the catalog and the look of a rank are validated; powers can be given at creation
  const cat = (await ranks()).powers.map(p => p.key);
  for (const k of ["find_users", "assign_rank", "rename_users", "ban_users", "limit_users", "limit_everyone", "room_lock", "room_edit_locked", "room_delete", "room_full", "bypass_features"]) assert.ok(cat.includes(k), "catalog has " + k);
  assert.ok(Object.keys((await ranks()).anims).includes("blood"), "blood dripping is offered");
  const bad = [{ mode: "rainbow" }, { anim: "explode" }, { speed: "warp" }, { palette: ["#fff"] }, { palette: ["#ff0000", "#00ff00", "#0000ff", "#ffff00", "#ff00ff", "#00ffff"] }, { palette: "red" }, { powers: ["nope"] }, { powers: "ban_users" }];
  for (const b of bad) assert.strictEqual((await call(dev.cookie, "/api/dev/ranks", { name: "Bad", color: "#ff0000", ...b })).status, 400, "rejects " + JSON.stringify(b));
  const allMod = ["find_users", "assign_rank", "rename_users", "ban_users", "room_lock", "room_edit_locked", "room_delete", "bypass_features"];
  const made = await call(dev.cookie, "/api/dev/ranks", { name: "Mod", color: "#FF0000", palette: ["#FF0000", "#AA0000"], anim: "blood", speed: "fast", powers: allMod });
  assert.strictEqual(made.status, 200);
  assert.deepStrictEqual((await made.json()).ranks.find(r => r.name === "Mod"), { name: "Mod", color: "#ff0000", powers: allMod, mode: "mix", anim: "blood", palette: ["#ff0000", "#aa0000"], speed: "fast" });
  console.log("ok  powers: ranks are created with a look and powers; bad animations, speeds, palettes and unknown powers are refused");

  // 2. edit the look later; everybody is told live
  const watcher = await join(B, (await mkRoom(B.cookie)).id), told = watcher.c.next("ranks-updated");
  const styled = await call(dev.cookie, "/api/dev/ranks/style", { name: "Mod", anim: "fire", palette: ["#FFAA00", "#FF2200", "#ffee00"], color: "#ff5500", speed: "slow" });
  assert.strictEqual(styled.status, 200);
  const live = (await told).ranks.find(r => r.name === "Mod");
  assert.deepStrictEqual([live.anim, live.palette, live.color, live.speed], ["fire", ["#ffaa00", "#ff2200", "#ffee00"], "#ff5500", "slow"]);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/style", { name: "Mod", mode: "solid" })).status, 200, "Color only");
  assert.strictEqual((await ranks()).ranks.find(r => r.name === "Mod").mode, "solid");
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/style", { name: "Mod", mode: "mix" })).status, 200, "and back to Mix");
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/style", { name: "Mod", mode: "neon" })).status, 400);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/style", { name: "Mod", anim: "nope" })).status, 400);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/style", { name: "Ghost", anim: "glow" })).status, 404);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/style", { name: "Mod", palette: [] })).status, 200, "an empty palette is allowed");
  assert.deepStrictEqual((await ranks()).ranks.find(r => r.name === "Mod").palette, []);
  console.log("ok  powers: a rank's color, palette, animation and speed can be changed any time and reach everyone live");

  // 3. add and remove powers one at a time, or all at once
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks", { name: "Helper", color: "#22d3ee" })).status, 200);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Helper", power: "find_users", on: true })).status, 200);
  assert.deepStrictEqual((await ranks()).ranks.find(r => r.name === "Helper").powers, ["find_users"]);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Helper", power: "find_users", on: true })).status, 200);
  assert.deepStrictEqual((await ranks()).ranks.find(r => r.name === "Helper").powers, ["find_users"], "no duplicates");
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Helper", power: "nope", on: true })).status, 400);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Helper", power: "find_users" })).status, 400);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Nobody", power: "find_users", on: true })).status, 404);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Helper", powers: cat })).status, 200);
  assert.deepStrictEqual((await ranks()).ranks.find(r => r.name === "Helper").powers, cat, "the developer can give a rank every power");
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Helper", powers: [] })).status, 200);
  assert.deepStrictEqual((await ranks()).ranks.find(r => r.name === "Helper").powers, [], "and take them all away");
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Helper", power: "find_users", on: true })).status, 200);
  console.log("ok  powers: any power can be added to or removed from any rank, one at a time or all at once");

  // 4. the staff panel: a power opens exactly its own door
  await call(dev.cookie, "/api/dev/ranks/style", { name: "Mod", anim: "blood", color: "#ff0000" });
  assert.strictEqual((await giveRank("A", "Mod")).status, 200);
  assert.deepStrictEqual((await meOf(A)).powers.sort(), [...allMod].sort(), "/api/me tells you your powers");
  assert.strictEqual((await meOf(dev)).powers.includes("room_lock"), true); assert.ok((await meOf(dev)).powers.length >= cat.length, "developers hold every power");
  assert.strictEqual((await get(B.cookie, "/api/roles?q=Cy")).status, 404, "no rank, no staff panel");
  assert.strictEqual((await get(A.cookie, "/api/roles?q=Cy")).status, 200, "find_users opens people search");
  assert.strictEqual((await call(B.cookie, "/api/dev/ban", { userNumber: ids.C, banned: true })).status, 404);
  assert.strictEqual((await call(A.cookie, "/api/dev/features", { userNumber: ids.C, feature: "chat", off: true })).status, 404, "limit_users is not in Mod");
  assert.strictEqual((await call(A.cookie, "/api/dev/features", { feature: "chat", off: true })).status, 404, "limit_everyone is not in Mod");
  for (const url of ["/api/dev/ranks", "/api/dev/ranks/delete", "/api/dev/ranks/style", "/api/dev/ranks/powers", "/api/dev/powers", "/api/dev/powers/delete"])
    assert.strictEqual((await call(A.cookie, url, { name: "Mod", label: "Sneaky", key: "x", power: "find_users", on: true })).status, 404, "staff can never edit ranks or powers: " + url);
  assert.strictEqual((await get(A.cookie, "/api/dev/overview")).status, 200, "ban_users shows the ban list");
  assert.strictEqual((await get(B.cookie, "/api/dev/overview")).status, 404);
  console.log("ok  powers: every staff action needs its own power; rank and power editing stays developer-only");

  // 5. staff can only act on people who hold fewer powers
  await giveRank("B", "Helper");                                               // Helper: find_users only (fewer than Mod)
  assert.strictEqual((await call(A.cookie, "/api/dev/ban", { userNumber: ids.B, banned: true, reason: "x" })).status, 200, "Mod can ban a Helper");
  assert.strictEqual((await call(A.cookie, "/api/dev/ban", { userNumber: ids.B, banned: false })).status, 200);
  assert.strictEqual((await call(A.cookie, "/api/dev/ban", { userNumber: ids.C, banned: true })).status, 200, "and someone with no rank");
  assert.strictEqual((await call(A.cookie, "/api/dev/ban", { userNumber: ids.C, banned: false })).status, 200);
  assert.strictEqual((await call(A.cookie, "/api/dev/ban", { userNumber: ids.A, banned: true })).status, 403, "not yourself");
  assert.strictEqual((await call(A.cookie, "/api/dev/ban", { userNumber: 1, banned: true })).status, 403, "never a developer");
  assert.strictEqual((await call(A.cookie, "/api/dev/rename", { userNumber: 6, name: "Hax" })).status, 403);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks", { name: "Mod2", color: "#00ff00", powers: allMod })).status, 200);
  await giveRank("D", "Mod2");
  assert.strictEqual((await call(A.cookie, "/api/dev/ban", { userNumber: ids.D, banned: true })).status, 403, "peers with the same powers are off limits");
  assert.strictEqual((await call(A.cookie, "/api/dev/rename", { userNumber: ids.D, name: "Nope" })).status, 403);
  assert.strictEqual((await call(A.cookie, "/api/dev/rename", { userNumber: ids.C, name: "Cyrus" })).status, 200, "rename needs rename_users, which Mod has");
  assert.strictEqual((await meOf(C)).name, "Cyrus");
  console.log("ok  powers: staff can't act on developers, themselves, or anyone with as many powers as they have");

  // 6. handing out ranks: only ranks whose powers you hold too, never your own, never a peer's
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks", { name: "Senior", color: "#ffd700", powers: [...allMod, "limit_users", "limit_everyone"] })).status, 200);
  assert.strictEqual((await call(A.cookie, "/api/roles", { userNumber: ids.E, role: "Helper" })).status, 200, "a rank with fewer powers is fine");
  assert.strictEqual((await meOf(E)).role, "Helper");
  assert.strictEqual((await call(A.cookie, "/api/roles", { userNumber: ids.E, role: "Mod" })).status, 200, "a rank with exactly your powers is fine too");
  assert.strictEqual((await call(A.cookie, "/api/roles", { userNumber: ids.C, role: "Senior" })).status, 403, "a rank with MORE powers than you is not");
  assert.strictEqual((await call(A.cookie, "/api/roles", { userNumber: ids.A, role: null })).status, 403, "can't change your own rank");
  assert.strictEqual((await call(A.cookie, "/api/roles", { userNumber: ids.D, role: null })).status, 403, "can't demote a peer");
  assert.strictEqual((await call(A.cookie, "/api/roles", { userNumber: ids.E, role: null })).status, 403, "E is now a Mod, a peer");
  assert.strictEqual((await call(dev.cookie, "/api/roles", { userNumber: ids.E, role: "Helper" })).status, 200);
  assert.strictEqual((await call(A.cookie, "/api/roles", { userNumber: ids.E, role: null })).status, 200, "a Helper can be demoted by a Mod");
  assert.strictEqual((await call(A.cookie, "/api/roles", { userNumber: 1, role: "Helper" })).status, 403);
  assert.strictEqual((await call(dev.cookie, "/api/roles", { userNumber: ids.C, role: "Senior" })).status, 200, "the developer can give any rank to anyone");
  await giveRank("C", null);
  console.log("ok  powers: staff can only give ranks whose powers they hold; no self-promotion, no demoting peers");

  // 7. taking a power away works at once; so does deleting the rank
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Mod", power: "ban_users", on: false })).status, 200);
  assert.strictEqual((await call(A.cookie, "/api/dev/ban", { userNumber: ids.C, banned: true })).status, 404, "the door closes the moment the power is gone");
  assert.strictEqual((await call(A.cookie, "/api/dev/rename", { userNumber: ids.C, name: "Cy" })).status, 200, "other powers are untouched");
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Mod", power: "ban_users", on: true })).status, 200);
  assert.strictEqual((await call(A.cookie, "/api/dev/ban", { userNumber: ids.C, banned: true })).status, 200);
  await call(A.cookie, "/api/dev/ban", { userNumber: ids.C, banned: false });
  console.log("ok  powers: removing a power closes its door immediately; adding it opens it again");

  // 8. custom powers: invent, give, see, delete
  const made2 = await call(dev.cookie, "/api/dev/powers", { label: "  Post   announcements " });
  assert.strictEqual(made2.status, 200); assert.strictEqual((await made2.json()).key, "post_announcements");
  assert.ok((await ranks()).powers.some(p => p.key === "post_announcements" && p.custom === true && p.label === "Post announcements"));
  for (const label of ["", "1abc", "x", "a".repeat(31), "<b>hi", "Find users", "post announcements"]) assert.ok([400, 409].includes((await call(dev.cookie, "/api/dev/powers", { label })).status), "rejects " + JSON.stringify(label));
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/powers", { name: "Helper", power: "post_announcements", on: true })).status, 200);
  assert.ok((await meOf(B)).powers.includes("post_announcements"), "the person can see they hold it, so your own code can use it");
  assert.strictEqual((await call(dev.cookie, "/api/dev/powers/delete", { key: "find_users" })).status, 400, "built-in powers stay, switch them off per rank instead");
  assert.strictEqual((await call(dev.cookie, "/api/dev/powers/delete", { key: "ghost_power" })).status, 404);
  assert.strictEqual((await call(dev.cookie, "/api/dev/powers/delete", { key: "post_announcements" })).status, 200);
  assert.ok(!(await ranks()).ranks.find(r => r.name === "Helper").powers.includes("post_announcements"), "deleting a power removes it from every rank");
  assert.ok(!(await meOf(B)).powers.includes("post_announcements"));
  console.log("ok  powers: the developer can invent powers, give them to ranks, and delete them again");

  // 9. workspace powers: lock, edit while locked, delete, ignoring feature switches
  const owner = await newUser("Olga"), visitor = await newUser("Vik");
  const room = await mkRoom(owner.cookie);
  const O = await join(owner, room.id, room.ownerToken), V = await join(visitor, room.id), S = await join(A, room.id);
  const vLock = V.c.next("permission-error"); V.c.emit("set-lock", { id: room.id, locked: true }); assert.ok((await vLock).includes("owner"), "no power, no key, no lock");
  const lockSeen = O.c.next("lock-state"); S.c.emit("set-lock", { id: room.id, locked: true });
  assert.strictEqual((await lockSeen).locked, true, "room_lock: a Mod locks a room without its owner key");
  const vEdit = V.c.next("permission-error"), vResync = V.c.next("resync"); V.c.emit("op", { id: room.id, rev: V.state.rev, op: OT.fromDiff(V.state.code, "visitor wrote") }); await vEdit; await vResync;
  const sAck = S.c.next("ack"); S.c.emit("op", { id: room.id, rev: S.state.rev, op: OT.fromDiff(S.state.code, "staff wrote") }); assert.ok(await sAck, "room_edit_locked: a Mod keeps editing a locked room");
  await call(dev.cookie, "/api/dev/ranks/powers", { name: "Mod", power: "room_edit_locked", on: false });
  const sBlocked = S.c.next("permission-error"), sResync = S.c.next("resync"); S.c.emit("op", { id: room.id, rev: S.state.rev + 1, op: OT.fromDiff("staff wrote", "again") }); await sBlocked; await sResync;
  const unlockSeen = O.c.next("lock-state"); S.c.emit("set-lock", { id: room.id, locked: false }); assert.strictEqual((await unlockSeen).locked, false);
  // feature switches: bypass_features
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { feature: "chat", off: true })).status, 200);
  const vChat = V.c.next("permission-error"); V.c.emit("chat", { id: room.id, text: "hello" }); assert.ok((await vChat).includes("Chat"));
  const heard = O.c.next("chat-msg"); S.c.emit("chat", { id: room.id, text: "staff can still talk" }); assert.strictEqual((await heard).text, "staff can still talk");
  assert.strictEqual((await call(A.cookie, "/api/rooms", { code: "x" })).status, 200, "bypass_features also covers creating workspaces");
  await call(dev.cookie, "/api/dev/features", { feature: "chat", off: false });
  // delete
  const vDel = V.c.next("permission-error"); V.c.emit("delete-room", { id: room.id }); assert.ok((await vDel).includes("owner"));
  const gone = O.c.next("room-deleted"); S.c.emit("delete-room", { id: room.id }); await gone;
  [O.c, V.c, S.c, watcher.c].forEach(c => c.close());
  console.log("ok  powers: a rank can lock, edit locked, delete any workspace and ignore feature switches; without the power the owner key is still required");

  server.close(); setTimeout(() => process.exit(0), 100);
})().catch(e => { console.error("FAIL", e); process.exit(1); });
