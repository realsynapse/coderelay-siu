process.env.DEV_MEMORY = "1"; process.env.DEV_MEMORY_DB = "1";
const assert = require("assert");
const WebSocket = require("ws");
const OT = require("../public/ot.js");
const { server } = require("../server.js");

function sioClient(port, cookie) {
  const ws = new WebSocket(`ws://127.0.0.1:${port}/socket.io/?EIO=4&transport=websocket`, { headers: cookie ? { cookie } : {} });
  const handlers = {}, log = []; let ok, bad; const ready = new Promise((a, b) => { ok = a; bad = b; });
  const api = {
    log, ready, closed: new Promise(r => ws.on("close", r)),
    emit(ev, payload) { ws.send("42" + JSON.stringify([ev, payload])); },
    next(ev, ms = 3000) { return new Promise((res, rej) => { const t = setTimeout(() => rej(new Error("timeout waiting for " + ev)), ms); (handlers[ev] = handlers[ev] || []).push(function once(d) { clearTimeout(t); handlers[ev] = handlers[ev].filter(x => x !== once); res(d); }); }); },
    count(ev) { return log.filter(x => x === ev).length; },
    close() { ws.close(); }
  };
  ws.on("message", raw => {
    const m = raw.toString();
    if (m === "2") return ws.send("3");
    if (m[0] === "0") return ws.send("40");
    if (m.startsWith("40")) return ok();
    if (m.startsWith("44")) return bad(new Error("refused: " + m));
    const mm = m.match(/^42(\d*)(\[.*)$/); if (!mm) return;
    const arr = JSON.parse(mm[2]); log.push(arr[0]);
    (handlers[arr[0]] || []).slice().forEach(fn => fn(arr[1]));
  });
  ws.on("error", () => bad(new Error("socket error")));
  return api;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(0, r));
  const port = server.address().port, base = `http://127.0.0.1:${port}`;
  const J = { "content-type": "application/json" };
  const newUser = async name => { const r = await fetch(base + "/api/me", { method: "POST", headers: J, body: JSON.stringify({ name }) }); return { body: await r.json(), cookie: (r.headers.get("set-cookie") || "").split(";")[0] }; };
  const call = (cookie, url, body, extra = {}) => fetch(base + url, { method: "POST", headers: { ...J, ...(cookie ? { cookie } : {}), ...extra }, body: JSON.stringify(body) });
  const get = (cookie, url) => fetch(base + url, { headers: cookie ? { cookie } : {} });
  const mkRoom = async cookie => (await (await call(cookie, "/api/rooms", { code: "x", language: "Plain text" })).json());
  const join = async (user, id) => { const c = sioClient(port, user.cookie); await c.ready; const st = c.next("room-state"); c.emit("join-room", { id }); return { c, state: await st }; };

  const dev = await newUser("Boss"), u2 = await newUser("Mira"), u3 = await newUser("Kabir"), u4 = await newUser("Filler4"), u5 = await newUser("Filler5"), u6 = await newUser("Dev2");
  assert.strictEqual(dev.body.user.dev, true);

  // 1. only the developer can use any of it (everyone else sees a plain 404; cross-site is refused)
  for (const [url, body] of [["/api/dev/ranks", { name: "Vip", color: "#ff0000" }], ["/api/dev/ranks/delete", { name: "Vip" }], ["/api/dev/rename", { userNumber: 3, name: "X" }], ["/api/dev/ban", { userNumber: 3, banned: true }], ["/api/dev/features", { userNumber: 3, feature: "chat", off: true }], ["/api/dev/features", { feature: "chat", off: true }], ["/api/dev/ranks/style", { name: "Vip", anim: "blood" }], ["/api/dev/ranks/powers", { name: "Vip", power: "ban_users", on: true }], ["/api/dev/powers", { label: "Extra" }], ["/api/dev/powers/delete", { key: "extra" }]]) {
    assert.strictEqual((await call(null, url, body)).status, 404, url + " anonymous");
    assert.strictEqual((await call(u2.cookie, url, body)).status, 404, url + " normal user");
  }
  assert.strictEqual((await get(u2.cookie, "/api/dev/overview")).status, 404);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks", { name: "Vip", color: "#ff0000" }, { origin: "http://evil.example" })).status, 403, "cross-site refused");
  console.log("ok  dev powers: every endpoint is 404 for anonymous and normal users; cross-site refused");

  // 2. ranks: created and deleted on the website, nothing built in
  assert.deepStrictEqual((await (await get(null, "/api/ranks")).json()).ranks, [], "no built-in ranks");
  assert.strictEqual((await call(dev.cookie, "/api/roles", { userNumber: 3, role: "admin" })).status, 400, "admin/moderator no longer exist");
  for (const bad of [{ name: "", color: "#ff0000" }, { name: "x".repeat(21), color: "#ff0000" }, { name: "<b>", color: "#ff0000" }, { name: "Developer", color: "#ff0000" }, { name: "dev", color: "#ff0000" }, { name: "Vip", color: "red" }, { name: "Vip", color: "javascript:1" }])
    assert.strictEqual((await call(dev.cookie, "/api/dev/ranks", bad)).status, 400, "rejects " + JSON.stringify(bad));
  const made = await call(dev.cookie, "/api/dev/ranks", { name: "Helper", color: "#22D3EE" });
  assert.strictEqual(made.status, 200); assert.deepStrictEqual((await made.json()).ranks, [{ name: "Helper", color: "#22d3ee", powers: [], mode: "mix", anim: "none", palette: [], speed: "normal" }]);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks", { name: "helper", color: "#000000" })).status, 409, "names are unique, ignoring case");
  const ra = await join(u2, (await mkRoom(u2.cookie)).id), watch = ra.c.next("ranks-updated");
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks", { name: "Star", color: "#ffb347" })).status, 200);
  assert.strictEqual((await watch).ranks.length, 2, "everyone connected is told the rank list changed");
  assert.strictEqual((await call(dev.cookie, "/api/roles", { userNumber: 3, role: "Star" })).status, 200);
  assert.strictEqual((await (await get(u3.cookie, "/api/me")).json()).user.role, "Star");
  const pres = ra.c.next("presence"); await call(dev.cookie, "/api/dev/ranks/delete", { name: "Star" }); await pres;
  assert.strictEqual((await (await get(u3.cookie, "/api/me")).json()).user.role, null, "deleting a rank removes it from everyone who had it");
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks/delete", { name: "Star" })).status, 404);
  assert.strictEqual((await call(dev.cookie, "/api/roles", { userNumber: 3, role: "Helper" })).status, 200);
  assert.strictEqual((await (await get(u3.cookie, "/api/me")).json()).user.role, "Helper");
  console.log("ok  dev powers: ranks are created and deleted on the website; deleting removes it from everyone, live");

  // 3. rename anybody (no 30-day wait), but not onto a taken name, and never a developer
  assert.strictEqual((await call(dev.cookie, "/api/dev/rename", { userNumber: 3, name: "  Kabir<b>2  " })).status, 200);
  assert.strictEqual((await (await get(u3.cookie, "/api/me")).json()).user.name, "Kabirb2", "< and > are stripped like in every name");
  assert.strictEqual((await call(dev.cookie, "/api/dev/rename", { userNumber: 3, name: "mira" })).status, 409, "taken");
  assert.strictEqual((await call(dev.cookie, "/api/dev/rename", { userNumber: 3, name: "   " })).status, 400);
  assert.strictEqual((await call(dev.cookie, "/api/dev/rename", { userNumber: 6, name: "Renamed" })).status, 403, "another developer account can't be changed by others");
  assert.strictEqual((await call(dev.cookie, "/api/dev/rename", { userNumber: 999, name: "Nobody" })).status, 404);
  assert.strictEqual((await call(dev.cookie, "/api/dev/rename", { userNumber: "3", name: "Nope" })).status, 400);
  assert.strictEqual((await call(dev.cookie, "/api/dev/rename", { userNumber: 3, name: "Kabir" })).status, 200, "can rename again immediately");
  console.log("ok  dev powers: rename anybody at any time; taken, empty and developer targets are refused");

  // 4. feature switches: per person, and for everybody except developers
  const roomK = await mkRoom(u3.cookie), K = await join(u3, roomK.id), M = await join(u2, roomK.id), D = await join(dev, roomK.id);
  const me3 = K.c.next("me-updated");
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { userNumber: 3, feature: "nope", off: true })).status, 400);
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { userNumber: 3, feature: "chat", off: true })).status, 200);
  assert.deepStrictEqual((await me3).user.off, ["chat"], "the person is told live");
  K.c.emit("chat", { id: roomK.id, text: "hi" }); assert.strictEqual((await K.c.next("permission-error")).includes("Chat"), true);
  const mm = M.c.next("chat-msg"); M.c.emit("chat", { id: roomK.id, text: "still works for others" }); assert.strictEqual((await mm).text, "still works for others");
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { userNumber: 3, feature: "edit", off: true })).status, 200);
  const rs = K.c.next("resync"), pe = K.c.next("permission-error"); K.c.emit("op", { id: roomK.id, rev: K.state.rev, op: OT.fromDiff(K.state.code, "changed") }); await pe; await rs;
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { userNumber: 3, feature: "create", off: true })).status, 200);
  const blocked = await call(u3.cookie, "/api/rooms", { code: "x", language: "Plain text" }); assert.strictEqual(blocked.status, 403);
  assert.strictEqual((await call(u2.cookie, "/api/rooms", { code: "x", language: "Plain text" })).status, 200, "others can still create");
  assert.deepStrictEqual((await (await get(u3.cookie, "/api/me")).json()).user.off.sort(), ["chat", "create", "edit"]);
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { userNumber: 3, feature: "chat", off: false })).status, 200);
  const back = M.c.next("chat-msg"), mine = K.c.next("chat-msg"); K.c.emit("chat", { id: roomK.id, text: "back" }); assert.strictEqual((await back).text, "back"); await mine;
  // global
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { feature: "create", off: true })).status, 200);
  assert.strictEqual((await call(u2.cookie, "/api/rooms", { code: "x" })).status, 403, "global switch blocks everyone");
  assert.strictEqual((await call(null, "/api/rooms", { code: "x" })).status, 403, "even visitors");
  assert.strictEqual((await call(dev.cookie, "/api/rooms", { code: "x" })).status, 200, "developers are never limited");
  assert.deepStrictEqual((await (await get(null, "/api/ranks")).json()).globalOff, ["create"]);
  await call(dev.cookie, "/api/dev/features", { feature: "create", off: false });
  assert.strictEqual((await call(u2.cookie, "/api/rooms", { code: "x" })).status, 200);
  await call(dev.cookie, "/api/dev/features", { userNumber: 3, feature: "edit", off: false }); await call(dev.cookie, "/api/dev/features", { userNumber: 3, feature: "create", off: false });
  console.log("ok  dev powers: features can be turned off per person or for everyone; developers are exempt; changes reach people live");

  // 5. ban
  const kickedMsg = M.c.next("banned"), closed = M.c.closed;
  const banned = await call(dev.cookie, "/api/dev/ban", { userNumber: 2, banned: true, reason: "spam <script>" });
  assert.strictEqual(banned.status, 200); assert.strictEqual((await banned.json()).user.banned, true);
  assert.strictEqual((await kickedMsg).reason, "spam script", "sockets are told why and disconnected");
  await closed;
  const apiBlocked = await get(u2.cookie, "/api/me"); assert.strictEqual(apiBlocked.status, 403); assert.strictEqual((await apiBlocked.json()).banned, true);
  const page = await get(u2.cookie, "/"); assert.strictEqual(page.status, 403); assert.ok((await page.text()).includes("has been banned"));
  assert.strictEqual((await get(u2.cookie, "/room/abc")).status, 403);
  const refused = sioClient(port, u2.cookie); await assert.rejects(refused.ready, /refused/, "a banned account can't connect");
  assert.strictEqual((await get(u3.cookie, "/api/me")).status, 200, "other people are unaffected");
  const ov = await (await get(dev.cookie, "/api/dev/overview")).json(); assert.deepStrictEqual(ov.banned.map(b => [b.id, b.name]), [[2, "Mira"]]);
  assert.strictEqual((await call(dev.cookie, "/api/dev/ban", { userNumber: 6, banned: true })).status, 403, "developers can't be banned (no lock-outs)");
  assert.strictEqual((await call(dev.cookie, "/api/dev/ban", { userNumber: 1, banned: true })).status, 403, "not even yourself");
  assert.strictEqual((await call(dev.cookie, "/api/dev/ban", { userNumber: 2, banned: false })).status, 200);
  assert.strictEqual((await get(u2.cookie, "/api/me")).status, 200, "unbanned: back in");
  const again = sioClient(port, u2.cookie); await again.ready; again.close();
  console.log("ok  dev powers: a ban blocks pages, API and sockets at once and kicks live; unban restores access; developers can't be banned");

  [K.c, D.c, ra.c].forEach(c => c.close()); server.close(); setTimeout(() => process.exit(0), 100);
})().catch(e => { console.error("FAIL", e); process.exit(1); });
