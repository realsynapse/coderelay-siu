# SyncPit
*A project of Crown Lab*

Real-time team code editor. Share a QR code or link and edit the same code live. Workspaces are saved in Supabase, so they survive server restarts and redeploys, and edits made by anyone with the link are kept.

## What's new in this version
- **Console:** press Run (or Ctrl+Enter) to run JavaScript or Python. Code runs in a sandboxed page in your own browser, with no access to this site's data, no network, and a 5 second limit (Python: 30 s, first run downloads the runtime).
- **Merge-safe live editing:** two people typing at once no longer overwrite each other.
- **Encrypted at rest:** the server now requires `ENCRYPTION_KEY` (see `.env.example`) and refuses to start without it. Back the key up.
- Strict security headers, rate limits, and a sandbox for running code. Check everything with `node test/ot.test.js` and `node test/server.test.js`.

## 1. Set up Supabase (once)
1. Create a project at https://supabase.com.
2. Open **SQL Editor**, paste the contents of `supabase/schema.sql`, and run it.
3. Open **Project Settings -> API** and copy the **Project URL** and the **service_role** key.

## 2. Configure
Copy `.env.example` to `.env` and fill in:
```
SUPABASE_URL=...
SUPABASE_SERVICE_ROLE_KEY=...
```
The service_role key stays on the server only. Never put it in `public/`, commit it, or share it. When you deploy (Render, Railway, etc.), add the same two values as environment variables instead of uploading `.env`.

## 3. Run
```
npm install
node server.js
```
Open http://localhost:3000. (To share with people outside your network, deploy to a Node host that supports WebSockets.)

## Favicon
Put your icon (png, ico, svg, jpg, webp or gif, any file name) into the `favicon/` folder. It shows in the browser tab automatically, with no code change. Refresh the page (Ctrl+F5 if the tab still shows the old icon). With no file there, a default red `</>` mark is used.

## Syntax colours
The editor colours code live as you type (VS Code Dark+ style). Language is set to Auto detect by default; pick a language manually to override. Colours are the `.t-*` classes in `public/index.html`.

## Notes
- Only the latest version of each workspace is stored; there is no edit history.
- Anyone with a workspace link can edit while it is unlocked. The owner's Lock editing switch makes it read-only for everyone else. It is a permission lock. Stored workspace content is separately encrypted at rest.
- Do not paste passwords, API keys, or other secrets into a shared workspace.
- Edits are saved about half a second after typing stops, and pending edits are flushed when the server stops.


## Owner key
Whoever creates a workspace is its owner. The owner key is a random 256-bit secret; the server stores only its SHA-256 hash.
- The owner sees an **Owner key** box (nobody else does). **Copy owner link** copies `/room/<id>#owner=<key>`. Opening that link on any device restores lock/delete control. The part after `#` is never sent to the server or logged, and the app removes it from the address bar right away.
- **Reset owner key** creates a new key and immediately invalidates the old one (and any device using it). Use it if a link may have leaked.
- Wrong owner keys are rate limited per IP.

## Settings (gear button)
Click the gear next to the theme button: **Account** (change your name once every 30 days, sign in to save the account, log out), **Workspaces** (your saved workspaces and counts), **Appearance** (system / light / dark) and **Limits** (the real limits the server enforces). Run `supabase/schema.sql` again to add the `name_changed_at` column.

## Sign in with Google directly (shows your own address, not supabase.co)
Instead of going through Supabase, Google can sign people in straight to this site, so Google's screen shows `syncpit.onrender.com`.
1. Google Cloud > Credentials > your OAuth client > **Authorized redirect URIs**: add `https://syncpit.onrender.com/auth/callback` (the Supabase one is no longer needed for Google). Save.
2. Render > Environment: add `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` (both from that Google client) and `AUTH_PROVIDERS=google`. Optional: `PUBLIC_URL=https://syncpit.onrender.com`.
3. Redeploy. GitHub and the other providers still use Supabase as described below.
Only the Google name is requested (scope `openid profile`): no email.

## Sign in (Google, GitHub, ...)
Optional. Without it SyncPit asks for a name, exactly as before. Everything runs on the server (Supabase Auth, PKCE), so no provider keys ever reach the browser.
1. Run `supabase/schema.sql` in the Supabase SQL Editor (adds `auth_id`, `auth_provider` and the `user_sessions` table).
2. Supabase > Authentication > URL Configuration: set **Site URL** to `https://syncpit.onrender.com` and add `https://syncpit.onrender.com/auth/callback` under **Redirect URLs**.
3. Supabase > Authentication > Providers: enable Google and/or GitHub (each page shows the callback URL to paste into the Google Cloud / GitHub OAuth app, and takes back a Client ID and Secret).
4. Render > Environment: add `AUTH_PROVIDERS=google,github` (also available: discord, azure, twitter, facebook, apple, linkedin_oidc, gitlab, twitch) and save.
- A guest who signs in keeps their number, workspaces and counts. Signing in on another device opens the same account.
- Only a private sign-in ID and the provider name are stored. No email, no photo, no password.

## Ranks, powers and looks (developer panel)

- **Ranks** are made in the Developer panel. Each has a main color, a style (**Color only** or **Mix**), an optional palette, an effect (blood dripping, fire, frost, neon, glitch, sparkle, shimmer, glow) and a speed.
- **Mix** gives the same flowing border, name and tag as the developer. Leave the palette empty for an automatic rainbow built around the main color, or pick up to 5 colors.
- **Powers** are switched on or off per rank (find users, give/remove ranks, rename, ban, limit features, lock / delete / edit-while-locked / join-full workspaces, ignore feature switches). You can invent your own. Developers always hold every power; only developers edit ranks and powers; staff can only act on people with fewer powers than they have. Every check runs on the server.
